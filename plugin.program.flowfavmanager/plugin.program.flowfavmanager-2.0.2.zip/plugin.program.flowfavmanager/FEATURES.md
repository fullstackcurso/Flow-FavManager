# Features you'll find in this project:


Flow FavManager is a favourites manager for Kodi. The native interface offers limited control over ordering and organising favourites; this addon covers that gap with a full management layer rather than a simple reorganiser.

#### Here are some of the features Flow FavManager offers:

#### 1. List and Profile Management
*   **Multi-Profile System:** Create, save and load multiple profiles, each stored as an independent JSON file. This keeps separate sets of favourites for different uses (e.g. kids, sports, films).
*   **Predefined Templates:** Load pre-defined favourite lists to populate a new Kodi installation.
*   **Template Editor:** Create, edit, import, export and reset your own template categories and items, not just the bundled ones.
*   **Quick Save:** Update the active profile without going through the confirmation menus.
*   **Import and Export:** Share profiles or move them between devices as XML files. Each profile can also be exported individually to its own XML file, and renamed or deleted from the same menu.
*   **Profile Browser:** Navigate a profile's contents as a standard Kodi folder without loading it as your active favourites.
*   **Dynamic Widget (Clean View Path):** A dedicated `/widget` path that exposes favourites as plain folders, intended to feed home-screen widgets in skins such as Aura, Arctic and Titan without the management buttons.

#### 2. Security and Privacy
*   **PIN Protection:** Lock the addon behind a numeric PIN, requested when you open Flow FavManager.
*   **Session Lock:** Once authenticated during a Kodi session, the addon does not ask for the PIN again until the session ends.
*   **Security Question:** An optional, user-configured recovery method to restore access if the PIN is forgotten.
*   **Rescue Mechanism:** An emergency `RESET_FILE` to recover access without losing data if the password is lost.
*   **Audit Log:** Internal logging of critical actions: security changes, profile deletions and failed access attempts.

#### 3. Bulk Organization and Automation Tools
*   **Flexible Reordering:** Reorder items in the visual editor with four selectable modes: swap two items, insert before, insert after, or move with the up/down arrows.
*   **Quick Move (per item):** From the context menu of any item in the advanced editor, jump it 1, 5 or 10 positions up/down, or send it straight to the top or bottom of the list.
*   **Multiselect Mode:** Select multiple favourites at once (checkbox style) to perform batch actions.
*   **Group Operations:**
    *   **Bulk Move:** Move a block of favourites to a new position in one operation (e.g. 20 channels from position 100 to position 1).
    *   **Bulk Delete:** Select and remove multiple items at once.
    *   **Bulk Coloring:** Apply a label colour to a whole selected group.
*   **Automatic Grouping:** Scans the list and regroups favourites by their source addon (e.g. all Netflix items together, all YouTube items together).
*   **Bulk Sorting:** Sort the whole list alphabetically (A-Z / Z-A) or reverse the current order.
*   **Profile Search:** Search by name across all your saved profiles and open any matching favourite directly.

#### 4. Deep Visual Editing and Customization
*   **Label Styling:** Change the text colour of individual favourites, or apply bold, italic or uppercase formatting.
*   **Separator Bars:** Insert visual separators (lines or text with no action) to divide the list into sections. When deleting a separator you can remove just the separator or the whole section beneath it.
*   **Icon Management:**
    *   **Automatic Enrichment:** Attempts to find and assign icons to favourites that lack one.
    *   **Manual Change:** Pick a custom image for any favourite from local storage.
*   **Accessibility Mode:** Settings to improve visibility, such as high-contrast modes and adapted palettes (e.g. colour-blind mode).

#### 5. Advanced Creation and Manipulation
*   **Manual Item Creation:** Create a favourite from scratch by entering the label and the path (URL/command) manually, for users who know Kodi's internal paths.
*   **Entry Duplication:** Clone an existing favourite to create variations of the same channel or path.
*   **Path Editing:** Edit the command or URL of an existing favourite without deleting and recreating it.
*   **Addon Selector:** A built-in browser to locate and add favourites from any installed addon without leaving the editor.
*   **Global Context Menu:** Add content to a profile from any Kodi list (movies, channels, music) through the context menu (right click), without opening the addon.
*   **Compatibility Maximizer:** Internal logic (`build_list_item`) that normalises problematic URLs (scripts, commands without quotes) so favourites remain runnable, working around limitations of Kodi's favourites format.

#### 6. Complete Backup System
*   **Backup/Restore:** Create full backups of the `favourites.xml` file and restore them at any time.

#### 7. Web Remote Control (New in v2.0.0)
*   **Browser-Based Management:** Access and organise favourites from any device on the local network (PC, phone, tablet) through a responsive web interface.
*   **Interactive Actions:** Move favourites up/down, rename and delete items, with modal dialogs and toast notifications.
*   **Artwork Loading:** Shows each favourite's cover/thumbnail artwork, served through a proxy that resolves Kodi image URLs.
*   **Visual Customization:** Adapts to the system's dark or light mode automatically.

#### 8. Auto-start Favourites on Startup (New in v2.0.0)
*   **Startup Launcher:** Configure up to three favourites (addons, lists, commands) to launch automatically when Kodi starts.

#### 9. Main Menu Redesign (New in v2.0.0)
*   **Custom White Icons:** Replaced the generic Kodi icons with custom white Material icons.
*   **Visual Style:** Simplified the colour scheme to white typography.

#### 10. Add Editor to Favourites (New in v2.0.0)
*   **Quick Shortcut Option:** A settings option to add the advanced editor directly to Kodi favourites.

#### 11. Quick Editor
*   **Dialog-Based Editing:** A lightweight editor built on plain Kodi dialogs (no graphical window) to move, rename and delete favourites.

#### 12. Additional Tools
*   **Open Kodi Favourites:** A shortcut that opens Kodi's native favourites window (picking the right one for your Kodi version).
*   **Save and Reload:** Reload the active profile and clear the texture cache so updated icons show up immediately.
*   **Multi-language Interface**
<br>

#### Of all these features, the ones described below are inspired by other projects.


As a preliminary step before development, existing solutions in the ecosystem were reviewed, which led to identifying the *Insert-Swap-Kodi-Favourites* addon by *doko-desuka* (2018-2024). That earlier project served as inspiration for seeing how certain features were implemented in the logic and interface for reordering favourites, although no code is shared between them. Flow FavManager was built from scratch, motivated, among other factors, by the absence of a licence in that addon and by the need for a different technical foundation to support all of its features (profiles, security, templates, and so on). The similarities relate strictly to design and user-experience decisions; the underlying logic was implemented differently.<br>Special thanks to doko-desuka for the work on *Insert-Swap-Kodi-Favourites*. In both addons, the user can select one favourite, then select another, and watch them swap positions. Although this approach had been considered from the start of the project, the earlier addon served as a reference for applying it in Kodi. Both addons also present a settings menu with equivalent options for adapting the display, letting the user choose between showing favourite names in a small size (the default) or a larger, more legible one, and whether to show small thumbnails to save space or large ones for greater visual clarity. The settings also let the user choose whether they prefer "Swap" or "Insert" behaviour by default when clicking (the option to move items with the arrows was added in Flow FavManager). Finally, that addon was used as a reference when implementing the editor's pop-up window.<br>All of the decisions described above are directly inspired by doko-desuka's addon. Their earlier work was an invaluable guide for defining these aspects of the user experience. Thank you for paving the way.


