# -*- coding: utf-8 -*-
import sys
import os
import shutil
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import xbmcaddon
import xml.etree.ElementTree as ET
import datetime
import re
import json
# Importar módulo de base de datos extraído
from resources.lib.database import (
    FavouriteEntry, 
    FavouritesEngine, 
    get_profiles, 
    save_profile, 
    load_profile, 
    delete_profile
)

# --- Constantes y Configuración ---
ADDON = xbmcaddon.Addon()
PLUGIN_ID = int(sys.argv[1]) if len(sys.argv) > 1 else -1
# Usar base_url fija para evitar acumulaciones en la ruta al navegar
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""
if not BASE_URL.endswith('/'): BASE_URL += '/'
PLUGIN_URL = BASE_URL # Alias para compatibilidad con código existente

# Compatibilidad para Kodi 19+
translatePath = xbmcvfs.translatePath if hasattr(xbmcvfs, 'translatePath') else xbmc.translatePath

PATHS = {
    'favourites': translatePath('special://userdata/favourites.xml'),
    'backup': translatePath('special://userdata/favourites.xml.bak'),
    'addon_path': ADDON.getAddonInfo('path'),
    'templates': os.path.join(ADDON.getAddonInfo('path'), 'resources', 'templates.json'),
    # Guardar perfiles en addon_data para que no se incluyan en el ZIP del addon y sean persistentes
    'profiles': translatePath('special://profile/addon_data/plugin.program.flowfavmanager/profiles')
}

if not os.path.exists(PATHS['profiles']):
    try:
        os.makedirs(PATHS['profiles'])
    except: pass

PROPS = {
    'result': 'flow_xml_output',
    'reorder_method': 'flow_action_mode',
    'font_size': 'flow_ui_font',
    'thumb_size': 'flow_ui_thumb'
}

DEBUG_MODE = True

def log_debug(msg):
    if DEBUG_MODE:
        xbmc.log('[Flow FavManager] ' + str(msg), xbmc.LOGINFO)

AUDIT_FILE = translatePath('special://profile/addon_data/plugin.program.flowfavmanager/audit.log')

def log_audit(action, details):
    """Registra eventos de seguridad y acciones importantes."""
    if ADDON.getSetting('enable_audit_log') != 'true': return
    
    try:
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        line = f"[{timestamp}] {action}: {details}\n"
        with open(AUDIT_FILE, 'a', encoding='utf-8') as f: 
            f.write(line)
    except Exception as e:
        log_debug(f"Error escribiendo audit log: {e}")


# --- GESTIÓN DE PERFILES ---
# (La lógica se ha movido a resources/lib/database.py)


# --- UTILS ---

def get_window_prop(prop_name):
    return xbmcgui.Window(xbmcgui.getCurrentWindowId()).getProperty(prop_name)

def set_window_prop(prop_name, value):
    xbmcgui.Window(xbmcgui.getCurrentWindowId()).setProperty(prop_name, value)

def clear_window_prop(prop_name):
    xbmcgui.Window(xbmcgui.getCurrentWindowId()).clearProperty(prop_name)

def load_templates():
    """Carga las plantillas personalizables desde JSON."""
    try:
        with open(PATHS['templates'], 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        log_debug("Error cargando templates: " + str(e))
        return {"secciones_kodi": [], "comandos_sistema": []}

def save_templates(data):
    """Guarda las plantillas en JSON."""
    try:
        with open(PATHS['templates'], 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        return True
    except Exception as e:
        log_debug("Error guardando templates: " + str(e))
        return False

# --- SISTEMA DE SEGURIDAD ---
SECURITY_FILE = translatePath('special://profile/addon_data/plugin.program.flowfavmanager/security.json')
RESET_FILE = translatePath('special://profile/addon_data/plugin.program.flowfavmanager/reset_pass.txt')
SESSION_UNLOCKED_PROP = 'FlowFavManager_Unlocked'

def load_security_config():
    """Carga la configuración de seguridad."""
    try:
        if os.path.exists(SECURITY_FILE):
            with open(SECURITY_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except:
        pass
    return {'enabled': False, 'pin': '', 'question': '', 'answer': ''}

def save_security_config(config):
    """Guarda la configuración de seguridad."""
    try:
        # Asegurar que exista el directorio
        dir_path = os.path.dirname(SECURITY_FILE)
        if not os.path.exists(dir_path):
            os.makedirs(dir_path)
        with open(SECURITY_FILE, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=4)
        return True
    except Exception as e:
        log_debug("Error guardando seguridad: " + str(e))
        return False

def check_reset_file():
    """Comprueba si existe el archivo de reseteo de emergencia."""
    if os.path.exists(RESET_FILE):
        try:
            os.remove(RESET_FILE)
            # Desactivar seguridad
            config = load_security_config()
            config['enabled'] = False
            config['pin'] = ''
            save_security_config(config)
            xbmcgui.Dialog().ok("Seguridad Reseteada", 
                "Se ha detectado el archivo de recuperación.\n" +
                "La contraseña ha sido eliminada.\n" +
                "Puedes configurar una nueva en Ajustes.")
            log_audit("AUTH_RESET_FILE", "Seguridad reseteada mediante archivo de emergencia")
            return True
        except:
            pass
    return False

def is_session_unlocked():
    """Comprueba si ya hemos desbloqueado en esta sesión de Kodi."""
    # Usamos Window(10000) = Home, que persiste durante toda la sesión
    return xbmcgui.Window(10000).getProperty(SESSION_UNLOCKED_PROP) == 'true'

def set_session_unlocked():
    """Marca la sesión como desbloqueada."""
    xbmcgui.Window(10000).setProperty(SESSION_UNLOCKED_PROP, 'true')

def check_security_gate():
    """
    Comprueba si hay protección activa y pide el PIN.
    Devuelve True si puede continuar, False si debe bloquearse.
    """
    # 1. Comprobar archivo de reseteo de emergencia
    if check_reset_file():
        return True # Seguridad reseteada, dejar pasar
    
    # 2. Cargar config
    config = load_security_config()
    
    # 3. Si no está activado, dejar pasar
    if not config.get('enabled', False):
        return True
    
    # 4. Si ya desbloqueamos esta sesión, dejar pasar
    if is_session_unlocked():
        return True
    
    # 5. Pedir PIN
    pin_correcto = config.get('pin', '')
    intentos = 3
    
    while intentos > 0:
        kb = xbmc.Keyboard('', f'Introduce el PIN ({intentos} intentos)')
        kb.setHiddenInput(True) # Ocultar caracteres
        kb.doModal()
        
        if not kb.isConfirmed():
            return False # Canceló, bloquear
        
        if kb.getText() == pin_correcto:
            set_session_unlocked()
            return True # PIN correcto
        
        intentos -= 1
        if intentos > 0:
            xbmcgui.Dialog().notification("PIN Incorrecto", f"Te quedan {intentos} intentos", xbmcgui.NOTIFICATION_WARNING)
            log_audit("AUTH_FAIL_PIN", f"PIN incorrecto. Intentos restantes: {intentos}")
    
    # 6. Agotados los intentos, ofrecer recuperación
    recovery_opts = ['Responder Pregunta de Seguridad', 'Cancelar (Cerrar Addon)']
    sel = xbmcgui.Dialog().select("PIN Incorrecto - Recuperación", recovery_opts)
    
    if sel == 0: # Pregunta de seguridad
        question = config.get('question', '¿Pregunta no configurada?')
        answer_correct = config.get('answer', '').lower().strip()
        
        if not answer_correct:
            xbmcgui.Dialog().ok("Error", "No hay pregunta de seguridad configurada.\n\nPuedes crear un archivo 'reset_pass.txt' en la carpeta del addon para resetear.")
            return False
        
        kb = xbmc.Keyboard('', question)
        kb.doModal()
        
        if kb.isConfirmed() and kb.getText().lower().strip() == answer_correct:
            xbmcgui.Dialog().ok("Acceso Recuperado", "Respuesta correcta.\nLa protección se ha desactivado temporalmente.\nRecuerda configurar un nuevo PIN.")
            config['enabled'] = False
            save_security_config(config)
            set_session_unlocked()
            return True
        else:
            xbmcgui.Dialog().ok("Respuesta Incorrecta", "No se ha podido verificar.\n\nSi olvidaste todo, crea un archivo vacío llamado 'reset_pass.txt' en:\n" + os.path.dirname(SECURITY_FILE))
            log_audit("AUTH_FAIL_QUESTION", "Respuesta a pregunta de seguridad incorrecta")
            return False
    
            return False
    
    return False # Canceló

def build_list_item(entry):
    """Crea un ListItem optimizado y resuelve la URL de destino."""
    import urllib.parse
    
    li = xbmcgui.ListItem(label=entry.name)
    li.setArt({'thumb': entry.thumb, 'icon': entry.thumb})
    
    url = entry.url if entry.url else ""
    target_url = ""
    is_folder = False
    
    # 1. Rutas directas de Plugin (plugin://...)
    if url.lower().startswith('plugin://'):
        target_url = url
        is_folder = True
        
    # 2. Comandos RunAddon("id") -> Convertir a ruta navegable plugin://id/
    elif url.startswith('RunAddon('):
        match = re.search(r'RunAddon\("?([^")\s]+)"?\)', url)
        if match:
            addon_id = match.group(1)
            target_url = "plugin://{}/".format(addon_id)
            is_folder = True
        else:
            target_url = BASE_URL + 'execute?cmd=' + urllib.parse.quote(url)
            is_folder = False

    # 3. URLs script:// -> Convertir a RunAddon y ejecutar
    elif url.lower().startswith('script://'):
        match = re.match(r'^script://([^/]+)/?', url, re.IGNORECASE)
        if match:
            addon_id = match.group(1)
            cmd = f'RunAddon("{addon_id}")'
            target_url = BASE_URL + 'execute?cmd=' + urllib.parse.quote(cmd)
            is_folder = False
        else:
            target_url = BASE_URL + 'execute?cmd=' + urllib.parse.quote(url)
            is_folder = False
            
    # 4. Otros comandos (ActivateWindow, etc.) -> Puente de ejecución
    else:
        target_url = BASE_URL + 'execute?cmd=' + urllib.parse.quote(url)
        is_folder = False
        
        # Excepción visual: Notificaciones (separadores)
        if 'Notification' in url:
             li.setProperty('IsPlayable', 'false')

    # FIX: Recursividad. Si apunta a este mismo addon, forzar Container.Update
    if 'plugin.program.flowfavs' in target_url and is_folder:
        cmd = f'Container.Update({target_url})'
        target_url = BASE_URL + 'execute?cmd=' + urllib.parse.quote(cmd)
        is_folder = False
        
    # Mejoras para Widgets (Metadata básica)
    li.setInfo('video', {'title': entry.name, 'plot': url})
        
    return li, target_url, is_folder

def run_security_menu():
    """Menú para gestionar la seguridad del addon."""
    while True:
        config = load_security_config()
        is_enabled = config.get('enabled', False)
        has_pin = bool(config.get('pin', ''))
        has_question = bool(config.get('answer', ''))
        
        status = "[COLOR lime]ACTIVADA[/COLOR]" if is_enabled else "[COLOR gray]Desactivada[/COLOR]"
        
        opts = [
            f"Estado: {status}",
            "Cambiar PIN" if has_pin else "Establecer PIN",
            "Configurar Pregunta de Seguridad",
            "Activar Protección" if not is_enabled else "Desactivar Protección",
            "[COLOR gray]« Volver[/COLOR]"
        ]
        
        sel = xbmcgui.Dialog().select("Seguridad y Contraseña", opts)
        
        if sel == -1 or sel == 4: return # Volver
        
        if sel == 0: # Info
            info_msg = "La protección por PIN evita que personas no autorizadas accedan al addon.\n\n"
            if is_enabled:
                info_msg += "Estado: ACTIVADA\n"
                info_msg += f"Pregunta configurada: {'Sí' if has_question else 'No'}\n\n"
                info_msg += "Para recuperar acceso si olvidas el PIN:\n"
                info_msg += "1. Responde la pregunta de seguridad.\n"
                info_msg += "2. O crea un archivo 'reset_pass.txt' en:\n"
                info_msg += os.path.dirname(SECURITY_FILE)
            else:
                info_msg += "Estado: Desactivada"
            xbmcgui.Dialog().textviewer("Información de Seguridad", info_msg)
            
        elif sel == 1: # Cambiar/Establecer PIN
            kb = xbmc.Keyboard('', 'Introduce el nuevo PIN (números recomendados)')
            kb.setHiddenInput(True)
            kb.doModal()
            if kb.isConfirmed() and kb.getText():
                new_pin = kb.getText()
                # Confirmar
                kb2 = xbmc.Keyboard('', 'Confirma el PIN')
                kb2.setHiddenInput(True)
                kb2.doModal()
                if kb2.isConfirmed() and kb2.getText() == new_pin:
                    config['pin'] = new_pin
                    save_security_config(config)
                    xbmcgui.Dialog().notification("PIN Guardado", "Recuerda configurar la pregunta de seguridad", xbmcgui.NOTIFICATION_INFO)
                else:
                    xbmcgui.Dialog().notification("Error", "Los PIN no coinciden", xbmcgui.NOTIFICATION_ERROR)
                    
        elif sel == 2: # Pregunta de seguridad
            questions = [
                "¿Nombre de tu primera mascota?",
                "¿Ciudad donde naciste?",
                "¿Año de nacimiento de tu madre?",
                "¿Nombre de tu mejor amigo de infancia?",
                "¿Tu comida favorita?",
                "[Escribir pregunta personalizada]"
            ]
            q_sel = xbmcgui.Dialog().select("Elige una pregunta de seguridad", questions)
            if q_sel < 0: continue
            
            if q_sel == len(questions) - 1: # Personalizada
                kb = xbmc.Keyboard('', 'Escribe tu pregunta')
                kb.doModal()
                if not kb.isConfirmed() or not kb.getText(): continue
                selected_question = kb.getText()
            else:
                selected_question = questions[q_sel]
            
            # Pedir respuesta
            kb = xbmc.Keyboard('', 'Respuesta (no distingue mayúsculas)')
            kb.doModal()
            if kb.isConfirmed() and kb.getText():
                config['question'] = selected_question
                config['answer'] = kb.getText()
                save_security_config(config)
                xbmcgui.Dialog().notification("Guardado", "Pregunta de seguridad configurada", xbmcgui.NOTIFICATION_INFO)
                
        elif sel == 3: # Activar/Desactivar
            if not is_enabled:
                # Activar
                if not has_pin:
                    xbmcgui.Dialog().ok("Configura un PIN", "Primero debes establecer un PIN antes de activar la protección.")
                    continue
                if not has_question:
                    if not xbmcgui.Dialog().yesno("Aviso", "No has configurado una pregunta de seguridad.\nSi olvidas el PIN, solo podrás recuperar acceso con el archivo de rescate.\n\n¿Activar de todos modos?"):
                        continue
                config['enabled'] = True
                save_security_config(config)
                xbmcgui.Dialog().notification("Protección Activada", "Se pedirá PIN al entrar", xbmcgui.NOTIFICATION_INFO)
            else:
                # Desactivar
                config['enabled'] = False
                save_security_config(config)
                xbmcgui.Dialog().notification("Protección Desactivada", "Acceso libre", xbmcgui.NOTIFICATION_INFO)

# --- Estructuras de Datos ---

# --- Estructuras de Datos ---
# (Las clases FavouriteEntry y FavouritesEngine se han movido a resources/lib/database.py)


# --- Controlador de Interfaz ---

class FavouritesEditor(xbmcgui.WindowXMLDialog):
    """Lógica principal de la ventana del editor."""
    
    # IDs de controles del XML - mapeados a modos de vista
    PANEL_IDS = {
        '0': 101,  # Cuadrícula Grande
        '1': 102,  # Cuadrícula Pequeña
        '2': 103,  # Lista Compacta
        '3': 104   # Lista Grande
    }
    ID_BTN_CLOSE = 301
    ID_BTN_RESTORE = 302

    def __init__(self, *args, **kwargs):
        super(FavouritesEditor, self).__init__(*args, **kwargs)
        self.engine = FavouritesEngine()
        self.entries = []
        self.list_items = []
        self.drag_origin_index = None
        self.unsaved_changes = False
        self._context_menu_lock = False
        self.panel = None
        self.panel_id = 101  # Default
        
        # Multiselección
        self.multiselect_active = False
        self.pending_move = False
        self.selected_indices = set()

    def onInit(self):
        # Determinar qué ID de panel usar según la propiedad view_mode
        view_mode = self.getProperty('view_mode') or '0'
        self.panel_id = self.PANEL_IDS.get(view_mode, 101)
        
        try:
            self.panel = self.getControl(self.panel_id)
        except Exception as e:
            log_debug("Error control panel: " + str(e))
            # Fallback al panel por defecto
            self.panel = self.getControl(101)
        
        # Aplicar configuración de UI
        # Aplicar configuración de UI
        self.setProperty(PROPS['reorder_method'], ADDON.getSetting('move_behavior') or '0')
        self.setProperty(PROPS['font_size'], ADDON.getSetting('text_scale') or '1')
        self.setProperty(PROPS['thumb_size'], ADDON.getSetting('icon_scale') or '0')
        
        # Establecer icono del addon para uso en XML
        icon_path = os.path.join(PATHS['addon_path'], 'icon.png')
        self.setProperty('addonIcon', icon_path)
        
        self.apply_color_settings()

        self.reload_data()

    def apply_color_settings(self):
        # Default colors (Oscuro/Cyan/Verde)
        bg_color = 'F0101010'
        bg_top = 'FF202020'
        select_color = 'FF12A0C7' # Cyan
        multiselect_color = 'FF00FF00' # Green
        
        # Colorblind Mode (Alto Contraste)
        is_colorblind = ADDON.getSetting('colorblindMode') == 'true'
        
        if is_colorblind:
            bg_color = 'FF000000' # Negro Puro
            bg_top = 'FF404040'   # Gris Oscuro
            select_color = 'FFFFFF00' # Amarillo intenso
            multiselect_color = 'FFFF0000' # Rojo intenso
            
        else:
            # Custom Colors
            try:
                idx_bg = int(ADDON.getSetting('colorBackground') or '0')
                idx_sel = int(ADDON.getSetting('colorSelection') or '0')
                idx_multi = int(ADDON.getSetting('colorMultiselect') or '0')
            except:
                idx_bg, idx_sel, idx_multi = 0, 0, 0
            
            # Map Backgrounds
            if idx_bg == 1: # Claro (Gris Medio)
                bg_color = 'FF505050'
                bg_top = 'FF707070'
            elif idx_bg == 2: # Gris Neutro
                bg_color = 'FF303030'
                bg_top = 'FF404040'
            elif idx_bg == 3: # Azul Profundo
                bg_color = 'FF050520'
                bg_top = 'FF101040'
                
            # Map Selection
            sel_colors = [
                'FF12A0C7', # Cyan
                'FF20E020', # Verde
                'FFE0E020', # Amarillo
                'FFE02020', # Rojo
                'FFE08020', # Naranja
                'FFE020E0'  # Violeta
            ]
            if 0 <= idx_sel < len(sel_colors):
                select_color = sel_colors[idx_sel]
                
            # Map Multiselect
            multi_colors = [
                'FF20E020', # Verde
                'FFE020E0', # Magenta
                'FFE0E020', # Amarillo
                'FFFFFFFF'  # Blanco
            ]
            if 0 <= idx_multi < len(multi_colors):
                multiselect_color = multi_colors[idx_multi]

        # Calculate Faded Selection (base color with 60 alpha)
        # 'FF...' -> '60...'
        select_color_faded = '60' + select_color[2:]
        
        # --- FONTS ---
        idx_font = ADDON.getSetting('text_scale') or '1'
        font_name = 'font13' # Default (Medium)
        
        if idx_font == '0': font_name = 'font12' # Small
        elif idx_font == '2': font_name = 'font30' # Large
        
        # Set Properties -> Skin Strings (Fix for white background when dialogs open)
        # Using Skin.String ensures values are accessible even when the editor loses focus (e.g. keyboard open)
        xbmc.executebuiltin('Skin.SetString(FavEdit_color_bg, %s)' % bg_color)
        xbmc.executebuiltin('Skin.SetString(FavEdit_color_bg_top, %s)' % bg_top)
        xbmc.executebuiltin('Skin.SetString(FavEdit_color_selection, %s)' % select_color)
        xbmc.executebuiltin('Skin.SetString(FavEdit_color_selection_faded, %s)' % select_color_faded)
        xbmc.executebuiltin('Skin.SetString(FavEdit_color_multiselect, %s)' % multiselect_color)
        xbmc.executebuiltin('Skin.SetString(FavEdit_font_name, %s)' % font_name)

    def reload_data(self):
        self.engine.load()
        self.entries = self.engine.entries
        # Guardar copia del estado original para poder restablecer
        self.original_entries = [FavouriteEntry(e.name, e.thumb, e.url) for e in self.entries]
        
        # Enriquecimiento automático de iconos
        changes = self.engine.enrich_missing_icons()
        if changes > 0:
            # Si hemos recuperado iconos, marcamos como cambios pendientes para que se puedan guardar
            self.unsaved_changes = True
            self.has_pending_auto_icons = True
            # Mostrar notificación discreta
            xbmcgui.Dialog().notification("Iconos Dinámicos", f"Se han recuperado {changes} iconos", xbmcgui.NOTIFICATION_INFO)
        else:
            self.unsaved_changes = False
            self.has_pending_auto_icons = False

        self.refresh_view()

    def reset_to_original(self):
        """Restablece los favoritos al estado original (desde que se abrió el editor)."""
        if not self.unsaved_changes:
            xbmcgui.Dialog().notification("Info", "No hay cambios que restablecer", xbmcgui.NOTIFICATION_INFO)
            return
            
        if xbmcgui.Dialog().yesno("Restablecer", "¿Descartar todos los cambios y volver al estado original?"):
            self.entries = [FavouriteEntry(e.name, e.thumb, e.url) for e in self.original_entries]
            self.unsaved_changes = False
            self.refresh_view()
            xbmcgui.Dialog().notification("Restablecido", "Cambios descartados", xbmcgui.NOTIFICATION_INFO)

    def refresh_view(self):
        self.panel.reset()
        self.list_items = []
        for i, entry in enumerate(self.entries):
            li = xbmcgui.ListItem(label=entry.name)
            li.setArt({'thumb': entry.thumb})
            li.setProperty('index', str(i))
            
            # Estado visual de seleccion
            if i in self.selected_indices:
                li.setProperty('multiselected', '1')
                
            self.list_items.append(li)
        if self.unsaved_changes:
            self.setProperty('UnsavedChanges', 'true')
        else:
            self.setProperty('UnsavedChanges', '')

        self.panel.addItems(self.list_items)
        
        # Restaurar estado del radiobutton
        try:
             self.getControl(308).setSelected(self.multiselect_active)
        except: pass

    def onClick(self, controlId):
        if controlId in self.PANEL_IDS.values():
            self.handle_panel_click()
        elif controlId == 301: # Guardar y Salir
            self.handle_close()
        elif controlId == 302: # Backup/Restaurar (Ahora incluye Guardar Perfil)
            self.handle_restore_menu()
        elif controlId == 303: # Ayuda
            self.show_help()
        elif controlId == 304: # Salir sin guardar
            self.handle_exit_no_save()
        elif controlId == 305: # Añadir... (Menú Add)
            self.handle_add_menu()
        elif controlId == 308: # Entrar Multiselección
            self.toggle_multiselect()
        
        # Acciones Multiselección
        elif controlId == 350: # Cancelar
            self.cancel_multiselect()
        elif controlId == 351: # Mover Aquí
            self.mass_move_here()
        elif controlId == 352: # Color
            self.mass_color()
        elif controlId == 353: # Eliminar
            self.mass_delete()
        
        # Iconos de barra lateral
        elif controlId == 309: # Ordenar
            self.sort_entries()
        elif controlId == 310: # Restablecer
            self.reset_to_original()
        elif controlId == 312: # Auto-Agrupar
            self.auto_group_by_addon()

    def auto_group_by_addon(self):
        """Reordena todos los favoritos agrupándolos por Addon ID/Tipo."""
        if not xbmcgui.Dialog().yesno("Auto-Agrupar", "Esto reorganizará tu lista agrupando los favoritos del mismo addon juntos (ordenados alfabéticamente).\nNo se crearán separadores.\n¿Proceder?"):
            return

        def get_sort_key(entry):
            # 1. Determinar Grupo (Addon Name o 'ZZ_Sistema')
            # Usamos 'zz' para que sistema salga al final, o '00' para el principio.
            # Usuario pidió "agrupa por tipo de acción o addon".
            
            group_name = "ZZ_Otros" # Default a final
            
            # Detectar Plugin
            match = re.search(r'^plugin://([^/]+)/', entry.url)
            if match:
                addon_id = match.group(1)
                try:
                    addon = xbmcaddon.Addon(addon_id)
                    name = addon.getAddonInfo('name')
                    # Limpiar tags de color del nombre del addon si los tiene
                    group_name = self._strip_tags(name).upper() 
                except:
                    group_name = addon_id.upper()
            
            elif 'ActivateWindow' in entry.url:
                group_name = "AAA_VENTANAS KODI" # Para que salgan antes? O al final?
            elif 'RunScript' in entry.url:
                group_name = "AAA_SCRIPTS"
            elif 'StartAndroidActivity' in entry.url:
                group_name = "APPS ANDROID"
                
            # 2. Retornar tupla para ordenación (Grupo, NombreItem)
            # Strip tags del nombre del item para orden limpio
            item_name = self._strip_tags(entry.name).upper()
            
            return (group_name, item_name)

        # Ordenar in-place
        self.entries.sort(key=get_sort_key)
        
        self.unsaved_changes = True
        self.refresh_view()
        xbmcgui.Dialog().notification("Agrupado", "Lista ordenada por Tipo/Addon", xbmcgui.NOTIFICATION_INFO)

    def show_help(self):
        method = self.getProperty(PROPS['reorder_method'])
        msg = ""
        
        if method == '0':
            msg = "Selecciona un favorito y luego otro.\nSe intercambiarán de lugar entre sí."
        elif method == '1':
            msg = "Selecciona un favorito y luego otro.\nEl primero se moverá justo [B]antes[/B] del segundo."
        elif method == '2':
             msg = "Selecciona un favorito y luego otro.\nEl primero se moverá justo [B]después[/B] del segundo."
        
        msg += "\n\n[I](Puedes cambiar este comportamiento en Configuración)[/I]"
        
        msg += "\n\n[B]MENÚ CONTEXTUAL[/B] (opciones del elemento):"
        msg += "\n- PC: Clic derecho o tecla 'C'"
        msg += "\n- Mando/TV: Botón 'Menú'"
        msg += "\n- Táctil: Pulsación Larga"
        
        msg += "\n\n[B]TIPS:[/B]"
        msg += "\n- [I]Restablecer[/I]: descarta TODOS los cambios y vuelve al estado inicial"
        msg += "\n- [I]Multiselección[/I]: selecciona varios para mover, colorear o eliminar en bloque"
        msg += "\n- Los separadores son favoritos que no hacen nada, solo organizan visualmente"
        
        xbmcgui.Dialog().ok("Ayuda e Instrucciones", msg)

    def onAction(self, action):
        action_id = action.getId()
        # Menú Contextual: 117 (ContextMenu), 101 (MouseRightClick)
        if action_id in [117, 101]:
            self.open_context_menu()
        # Atrás/Escape: 92, 10
        elif action_id in [92, 10]: 
            self.handle_close()
        # Eliminar: 18 (normalmente tecla X)
        elif action_id == 18:
            self.delete_selected_item()

    def handle_panel_click(self):
        selected_idx = self.panel.getSelectedPosition()
        if selected_idx < 0: return

        # Lógica Multiselección
        if self.multiselect_active:
            # Si estamos esperando destino para mover
            if self.pending_move:
                self.execute_mass_move(selected_idx)
                return

            # Toggle selección
            item = self.panel.getListItem(selected_idx)
            
            if selected_idx in self.selected_indices:
                self.selected_indices.remove(selected_idx)
                item.setProperty('multiselected', '')
            else:
                self.selected_indices.add(selected_idx)
                item.setProperty('multiselected', '1')
            
            # NO recargar la vista completa para no perder el scroll
            # Simplemente actualizar el estado visual del item actual
            return

        # Lógica Normal (Arrastrar/Intercambiar)
        if self.drag_origin_index is None:
            # Iniciar selección
            self.drag_origin_index = selected_idx
            self.list_items[self.drag_origin_index].setProperty('selected', '1')
            self.refresh_view_keep_selection(selected_idx)
        else:
            # Finalizar selección o deseleccionar
            if self.drag_origin_index == selected_idx:
                # Deseleccionar
                self.list_items[self.drag_origin_index].setProperty('selected', '')
                self.drag_origin_index = None
                self.refresh_view_keep_selection(selected_idx)
            else:
                # Ejecutar reordenamiento
                self.execute_reorder(self.drag_origin_index, selected_idx)

    def refresh_view_keep_selection(self, select_idx):
        # Reconstruir items con propiedades actualizadas
        self.list_items = []
        for i, entry in enumerate(self.entries):
            li = xbmcgui.ListItem(label=entry.name)
            li.setArt({'thumb': entry.thumb})
            li.setProperty('index', str(i))
            
            # Estado multiselección
            if i in self.selected_indices:
                li.setProperty('multiselected', '1')
            
            # Estado drag normal
            if i == self.drag_origin_index:
                li.setProperty('selected', '1')
                
            self.list_items.append(li)
            
        self.panel.reset()
        self.panel.addItems(self.list_items)
        if select_idx >= 0 and select_idx < len(self.list_items):
            self.panel.selectItem(select_idx)

    def execute_reorder(self, idx_a, idx_b):
        # Nueva lógica de movimiento
        # Modos: 0=Swap, 1=Insert Before, 2=Insert After
        mode = self.getProperty(PROPS['reorder_method'])
        
        if mode == '0':
            # SWAP Simple: Intercambio directo
            self._swap_items(idx_a, idx_b)
            final_focus = idx_b
        else:
            # MOVER: Extraer e insertar
            target = idx_b
            if mode == '2': # Insertar Después
                target += 1
            
            final_focus = self._move_item_to(idx_a, target)

        self.drag_origin_index = None
        self.unsaved_changes = True
        self.refresh_view()
        self.panel.selectItem(final_focus)

    def _swap_items(self, i1, i2):
        """Intercambia dos elementos de la lista en su lugar."""
        self.entries[i1], self.entries[i2] = self.entries[i2], self.entries[i1]

    def _move_item_to(self, src_idx, dest_idx):
        """Mueve un elemento de src a dest, ajustando índices."""
        # Validar limites
        dest_idx = max(0, min(dest_idx, len(self.entries)))
        
        item = self.entries.pop(src_idx)
        
        # Si el destino está después del origen, el índice de destino 'real'
        # se ha desplazado -1 al hacer el pop.
        if dest_idx > src_idx:
            dest_idx -= 1
            
        self.entries.insert(dest_idx, item)
        return dest_idx

    def open_context_menu(self):
        if self._context_menu_lock: return
        self._context_menu_lock = True
        
        idx = self.panel.getSelectedPosition()
        if idx < 0:
            self._context_menu_lock = False
            return

        # Título del menú con el nombre del item
        entry_name = self._strip_tags(self.entries[idx].name)
        header = "[B][COLOR yellow]{}[/COLOR][/B]".format(entry_name)
        
        opts = [header, 'Renombrar', 'Editar Comando', 'Cambiar Icono', 'Cambiar Color', 'Cambiar Formato', 'Mover', 'Duplicar', 'Eliminar', 'Cancelar']
        
        selection = xbmcgui.Dialog().contextmenu(opts)
        
        if selection == 0: return # Click en el título, no hacer nada
        elif selection == 1: self.rename_entry(idx)
        elif selection == 2: self.edit_entry_path(idx)
        elif selection == 3: self.change_icon_selected(idx)
        elif selection == 4: self.style_entry_color(idx)
        elif selection == 5: self.style_entry_format(idx)
        elif selection == 6: self.quick_move_entry(idx)
        elif selection == 7: self.duplicate_entry(idx)
        elif selection == 8: self.delete_selected_item()
        
        xbmc.sleep(200)
        self._context_menu_lock = False

    def _strip_tags(self, text):
        # Función auxiliar para limpiar texto
        text = re.sub(r'\[COLOR [^\]]+\]', '', text)
        text = re.sub(r'\[/COLOR\]', '', text)
        text = re.sub(r'\[/?(B|I|UPPERCASE|LOWERCASE)\]', '', text)
        return text.strip()

    def duplicate_entry(self, idx):
        """Duplica el elemento seleccionado y lo inserta justo después."""
        import time
        original = self.entries[idx]
        
        # Crear copia con nombre modificado
        new_name = original.name + " (copia)"
        
        # Hacer el URL único para que Kodi no lo ignore
        # Kodi usa el URL como identificador único
        unique_id = str(int(time.time() * 1000))[-6:]  # Últimos 6 dígitos del timestamp
        original_url = original.url
        
        if 'Notification(' in original_url:
            # Para separadores: modificar el mensaje
            # Notification("Sección", "texto") -> Notification("Sección", "texto #123456")
            new_url = original_url.replace(')', ' #{})'.format(unique_id), 1)
        elif original_url.endswith('/'):
            # Para plugin:// URLs: añadir parámetro
            new_url = original_url + '?_dup=' + unique_id
        elif '?' in original_url:
            # Ya tiene parámetros
            new_url = original_url + '&_dup=' + unique_id
        else:
            # Para otros comandos: añadir un comentario invisible al final
            # Esto funciona para la mayoría de comandos de Kodi
            new_url = original_url + ' '  # Espacio trailing hace la URL única
        
        copy = FavouriteEntry(new_name, original.thumb, new_url)
        
        # Insertar después del original
        self.entries.insert(idx + 1, copy)
        
        self.unsaved_changes = True
        self.refresh_view()
        
        # Seleccionar la copia
        self.panel.selectItem(idx + 1)
        xbmcgui.Dialog().notification("Duplicado", self._strip_tags(original.name), xbmcgui.NOTIFICATION_INFO, 2000)

    def quick_move_entry(self, idx):
        """Muestra submenú para mover rápidamente el elemento."""
        total = len(self.entries)
        
        opts = [
            '↑ Mover 1 arriba',
            '↑↑ Mover 5 arriba',
            '↑↑↑ Mover 10 arriba',
            '^^^ [B]AL PRINCIPIO[/B]',
            '↓ Mover 1 abajo',
            '↓↓ Mover 5 abajo',
            '↓↓↓ Mover 10 abajo',
            'vvv [B]AL FINAL[/B]',
            'Cancelar'
        ]
        
        sel = xbmcgui.Dialog().select('Mover elemento', opts)
        if sel < 0 or sel == 8: return
        
        entry = self.entries.pop(idx)
        new_idx = idx
        
        if sel == 0:   # 1 arriba
            new_idx = max(0, idx - 1)
        elif sel == 1: # 5 arriba
            new_idx = max(0, idx - 5)
        elif sel == 2: # 10 arriba
            new_idx = max(0, idx - 10)
        elif sel == 3: # Al principio
            new_idx = 0
        elif sel == 4: # 1 abajo
            new_idx = min(total - 1, idx + 1)
        elif sel == 5: # 5 abajo
            new_idx = min(total - 1, idx + 5)
        elif sel == 6: # 10 abajo
            new_idx = min(total - 1, idx + 10)
        elif sel == 7: # Al final
            new_idx = total - 1
        
        self.entries.insert(new_idx, entry)
        self.unsaved_changes = True
        self.refresh_view()
        self.panel.selectItem(new_idx)

    def sort_entries(self):
        """Muestra opciones de ordenación."""
        opts = [
            'Ordenar A → Z',
            'Ordenar Z → A', 
            'Invertir orden (voltear lista)',
            'Agrupar por TIPO / ADDON',
            'Cancelar'
        ]
        
        sel = xbmcgui.Dialog().select('Ordenar favoritos', opts)
        if sel < 0 or sel == 4: return
        
        if sel == 3: # Agrupar por Addon
            self.auto_group_by_addon()
            return

        if sel == 0: # A-Z
            self.entries.sort(key=lambda e: self._strip_tags(e.name).lower())
            msg = "Ordenado A → Z"
        elif sel == 1: # Z-A
            self.entries.sort(key=lambda e: self._strip_tags(e.name).lower(), reverse=True)
            msg = "Ordenado Z → A"
        elif sel == 2: # Invertir
            self.entries.reverse()
            msg = "Orden invertido"
        
        self.unsaved_changes = True
        self.refresh_view()
        xbmcgui.Dialog().notification("Ordenado", msg, xbmcgui.NOTIFICATION_INFO)

    def quick_save_profile(self):
        """Guarda el estado actual como un nuevo perfil."""
        default_name = "Backup " + datetime.datetime.now().strftime("%Y-%m-%d %H-%M")
        kb = xbmc.Keyboard(default_name, 'Nombre del nuevo perfil')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            profile_name = kb.getText()
            if save_profile(profile_name, self.entries):
                xbmcgui.Dialog().notification("Perfil Guardado", f"Guardado como '{profile_name}'", xbmcgui.NOTIFICATION_INFO)

    def style_entry_color(self, idx):
        entry = self.entries[idx]
        colors = [
            ('Sin color', None), ('Blanco', 'white'), ('Amarillo', 'yellow'),
            ('Naranja', 'orange'), ('Rojo', 'red'), ('Rosa', 'pink'),
            ('Violeta', 'violet'), ('Azul', 'blue'), ('Cyan', 'cyan'),
            ('Verde', 'green'), ('Lima', 'lime')
        ]
        
        sel = xbmcgui.Dialog().select('Selecciona Color', [c[0] for c in colors])
        if sel < 0: return

        clean = self._strip_tags(entry.name)
        color_code = colors[sel][1]
        
        if color_code:
            entry.name = '[COLOR {}]{}[/COLOR]'.format(color_code, clean)
        else:
            entry.name = clean
            
        self.unsaved_changes = True
        self.refresh_view_keep_selection(idx)

    def style_entry_format(self, idx):
        entry = self.entries[idx]
        formats = [
            ('Sin formato', ''), ('Negrita', 'B'), ('Cursiva', 'I'),
            ('Negrita + Cursiva', 'BI'), ('MAYÚSCULAS', 'UPPERCASE')
        ]
        
        sel = xbmcgui.Dialog().select('Selecciona Formato', [f[0] for f in formats])
        if sel < 0: return

        # Preservar color si existe
        color_match = re.search(r'\[COLOR ([^\]]+)\]', entry.name)
        color_tag = color_match.group(1) if color_match else None
        
        clean = self._strip_tags(entry.name)
        fmt_tag = formats[sel][1]
        
        if 'B' in fmt_tag: clean = '[B]{}[/B]'.format(clean)
        if 'I' in fmt_tag: clean = '[I]{}[/I]'.format(clean)
        if 'UPPERCASE' in fmt_tag: clean = '[UPPERCASE]{}[/UPPERCASE]'.format(clean)
        
        if color_tag:
            clean = '[COLOR {}]{}[/COLOR]'.format(color_tag, clean)
            
        entry.name = clean
        self.unsaved_changes = True
        self.refresh_view_keep_selection(idx)

    def rename_entry(self, idx):
        entry = self.entries[idx]
        kb = xbmc.Keyboard(self._strip_tags(entry.name), 'Renombrar Favorito')
        kb.doModal()
        if (kb.isConfirmed()):
            new_name = kb.getText()
            if new_name:
                # Mantener color/formato si lo tenía? Mejor reconstruirlo simple o intentar preservar.
                # Simplificación: el usuario renombra el texto base.
                # Si queremos mantener tags, es complejo. Asumimos renombrado total.
                entry.name = new_name
                self.unsaved_changes = True
                self.refresh_view_keep_selection(idx)

    def edit_entry_path(self, idx):
        entry = self.entries[idx]
        kb = xbmc.Keyboard(entry.url, 'Editar Comando / Ruta')
        kb.doModal()
        if (kb.isConfirmed()):
            new_path = kb.getText().strip()
            if new_path:
                entry.url = new_path
                self.unsaved_changes = True
                self.refresh_view_keep_selection(idx)
                xbmcgui.Dialog().notification("Actualizado", "Comando cambiado", xbmcgui.NOTIFICATION_INFO, 1000)

    def delete_selected_item(self):
        idx = self.panel.getSelectedPosition()
        if idx < 0: return
        
        entry = self.entries[idx]
        
        # Detectar si es un separador (por el comando usado al crearlo)
        is_separator = 'Notification("Sección"' in entry.url
        
        if is_separator:
            # Preguntar qué borrar
            opts = ['Solo el separador', 'Separador y todo su contenido', 'Cancelar']
            sel = xbmcgui.Dialog().select('Eliminar Sección: ' + self._strip_tags(entry.name), opts)
            
            if sel == -1 or sel == 2: return # Cancelar
            
            if sel == 0: # Solo separador
                self.entries.pop(idx)
                
            elif sel == 1: # Separador + Contenido
                # Borramos el separador
                self.entries.pop(idx)
                # Borramos lo siguiente mientras NO sea otro separador
                while idx < len(self.entries):
                    next_url = self.entries[idx].url
                    if 'Notification("Sección"' in next_url:
                        break # Hemos llegado al siguiente separador
                    
                    # Borrar item
                    self.entries.pop(idx)
                    
        else:
            # Borrado normal de un item
            if not xbmcgui.Dialog().yesno("Confirmar", "¿Eliminar '{}'?".format(self._strip_tags(entry.name))):
                return
            self.entries.pop(idx)
            
        self.unsaved_changes = True
        
        # Ajustar selección
        new_idx = min(idx, len(self.entries) - 1)
        self.refresh_view()
        if new_idx >= 0:
            self.panel.selectItem(new_idx)

    def handle_close(self):
        if self.unsaved_changes:
            # Comprobar si hay cambios automáticos de iconos pendientes
            if getattr(self, 'has_pending_auto_icons', False):
                # Preguntar SOLO si hay iconos automáticos
                q_msg = "Se han detectado y asignado iconos automáticamente para algunos favoritos.\n¿Quieres guardar estos nuevos iconos?"
                yes = xbmcgui.Dialog().yesno("Iconos Dinámicos", q_msg, yeslabel="Guardar Iconos", nolabel="Descartar Iconos")
                
                if not yes:
                    # El usuario NO quiere los iconos automáticos. Revertirlos.
                    reverted_count = 0
                    for entry in self.entries:
                        if getattr(entry, 'auto_icon', False):
                            entry.thumb = '' # Volver a dejar vacío
                            entry.auto_icon = False
                            reverted_count += 1
                    
                    xbmcgui.Dialog().notification("Iconos", f"Se han descartado {reverted_count} iconos", xbmcgui.NOTIFICATION_INFO)
                    
                    # Si no había otros cambios manuales, unsaved_changes podría pasar a False?
                    # Es complejo saberlo. Asumimos que guardamos el estado "limpio" de iconos
                    # que incluye cualquier otra modificación manual que haya hecho el usuario.
            
            xml_out = self.engine.generate_xml(self.entries)
            if self.engine.save(xml_out):
                xbmcgui.Dialog().notification("Flow FavManager", "Cambios guardados. Recarga el perfil para verlos.", xbmcgui.NOTIFICATION_INFO, 3000)
                log_audit("FAVOURITES_SAVED", f"Lista principal guardada con {len(self.entries)} items")
            else:
                xbmcgui.Dialog().notification("Error", "No se pudo guardar.", xbmcgui.NOTIFICATION_ERROR, 3000)
                log_audit("ERROR_SAVING", "Fallo al guardar favourites.xml")
        self.close()

    def handle_exit_no_save(self):
        if self.unsaved_changes:
            if not xbmcgui.Dialog().yesno('Salir', 'Tienes cambios sin guardar.\n¿Seguro que quieres salir y PERDERLOS?'):
                return
        self.close()

    def add_custom_item(self):
        # Cargar plantillas para construir menú dinámico
        templates = load_templates()
        
        # Menú base
        menu_items = ['[B]Personalizado / Manual[/B] (Escribir comando)']
        menu_actions = ['manual']
        
        # Añadir categorías dinámicas desde plantillas
        for cat_key in templates.keys():
            cat_display = cat_key.replace('_', ' ').title()
            menu_items.append(cat_display)
            menu_actions.append(('template', cat_key))
        
        # Addons instalados (siempre disponible)
        menu_items.append('Addons Instalados (Video y Programas)')
        menu_actions.append('addons')
        
        sel = xbmcgui.Dialog().select('¿Qué quieres añadir?', menu_items)
        if sel < 0: return # Cancelado
        
        name = ""
        path = ""
        thumb = "DefaultAddon.png"
        
        action = menu_actions[sel]
        
        if action == 'manual': # MANUAL
            # 1. Nombre
            kb = xbmc.Keyboard('', 'Nombre del Favorito')
            kb.doModal()
            if not kb.isConfirmed() or not kb.getText(): return
            name = kb.getText()

            # 2. Ruta
            kb = xbmc.Keyboard('', 'Ruta o Comando (Ej: ActivateWindow(...))')
            kb.doModal()
            if not kb.isConfirmed(): return
            path = kb.getText().strip()
            
            # 3. Icono
            browse_icon = xbmcgui.Dialog().browse(1, 'Seleccionar Imagen', 'pictures')
            thumb = browse_icon if browse_icon else 'DefaultAddon.png'
            
        elif action == 'addons': # ADDONS INSTALADOS
            addons = self.get_installed_addons(None) 
            if not addons:
                xbmcgui.Dialog().notification("Error", "No se encontraron addons", xbmcgui.NOTIFICATION_WARNING)
                return
            
            addons.sort(key=lambda x: x['name'].lower())
                
            s = xbmcgui.Dialog().select('Selecciona Addon', [a['name'] for a in addons])
            if s < 0: return
            
            sel_addon = addons[s]
            name = sel_addon['name']
            thumb = sel_addon['thumbnail']
            addon_id = sel_addon['addonid']
            addon_type = sel_addon.get('type', 'unknown')
            # SIEMPRE usar RunAddon para máxima compatibilidad
            # Evita problemas con plugin:// que a veces falla
            path = 'RunAddon("{}")'.format(addon_id)
                
        elif isinstance(action, tuple) and action[0] == 'template':
            # Categoría desde plantillas
            cat_key = action[1]
            items = templates.get(cat_key, [])
            if not items:
                xbmcgui.Dialog().notification("Aviso", "Esta categoría está vacía", xbmcgui.NOTIFICATION_WARNING)
                return
            
            cat_display = cat_key.replace('_', ' ').title()
            s = xbmcgui.Dialog().select('Selecciona de ' + cat_display, [i['name'] for i in items])
            if s < 0: return
            name = items[s]['name']
            path = items[s]['path']
            thumb = items[s]['icon']

        # Validar ruta vacía
        if not path:
             path = 'Notification("Atención", "Favorito sin ruta", 3000)'

        # Crear entrada
        entry = FavouriteEntry(name, thumb, path)
        self.entries.append(entry)
        
        self.unsaved_changes = True
        self.refresh_view()
        
        xbmc.sleep(100) 
        self.setFocus(self.panel)
        new_idx = len(self.entries) - 1
        self.panel.selectItem(new_idx)
        xbmcgui.Dialog().notification("Añadido", name, xbmcgui.NOTIFICATION_INFO, 2000)

    def get_installed_addons(self, type_filter):
        # Tipos que nos interesan
        types_to_check = ["xbmc.python.pluginsource", "xbmc.python.script"]
        all_addons = []
        
        for t in types_to_check:
            query = {
                "jsonrpc": "2.0", 
                "method": "Addons.GetAddons", 
                "params": {
                    "properties": ["name", "thumbnail"], 
                    "enabled": True,
                    "type": t
                }, 
                "id": 1
            }
            try:
                json_str = xbmc.executeJSONRPC(json.dumps(query))
                result = json.loads(json_str)
                if 'result' in result and 'addons' in result['result']:
                    # Añadir tipo para luego saber qué comando usar
                    for a in result['result']['addons']:
                        a['type'] = t
                        all_addons.append(a)
            except:
                pass
                
        return all_addons

    def add_separator(self):
        kb = xbmc.Keyboard('', 'Nombre de la Sección / Separador')
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText(): return
        name = kb.getText()
        
        # Selección de color
        colors = [
            ('Oro (Por defecto)', 'gold'), ('Blanco', 'white'), ('Amarillo', 'yellow'),
            ('Naranja', 'orange'), ('Rojo', 'red'), ('Rosa', 'pink'),
            ('Violeta', 'violet'), ('Azul', 'blue'), ('Cyan', 'cyan'),
            ('Verde', 'green'), ('Lima', 'lime'), ('Gris', 'gray')
        ]
        sel = xbmcgui.Dialog().select('Color del Separador', [c[0] for c in colors])
        color_code = colors[sel][1] if sel >= 0 else 'gold'
        
        # Formato: Texto primero, luego raya (tamaño ajustado)
        display_name = "[COLOR {}][B]{}[/B] ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬[/COLOR]".format(color_code, name.upper())
        
        # Acción dummy
        action = 'Notification("Sección", "{}", 1000)'.format(name)
        
        # Usamos icono de carpeta por defecto
        entry = FavouriteEntry(display_name, 'DefaultFolder.png', action)
        self.entries.append(entry)
        
        self.unsaved_changes = True
        self.refresh_view()
        self.panel.selectItem(len(self.entries)-1)

    def toggle_multiselect(self):
        self.multiselect_active = True
        self.selected_indices.clear()
        self.setProperty('multiselect_active', '1') # Activa grouplist B
        self.refresh_view_keep_selection(self.panel.getSelectedPosition())
        # Poner foco en la lista para empezar a seleccionar
        self.setFocus(self.panel)

    def cancel_multiselect(self):
        self.multiselect_active = False
        self.pending_move = False
        self.selected_indices.clear()
        self.clearProperty('multiselect_active') # Vuelve a grouplist A
        self.refresh_view_keep_selection(self.panel.getSelectedPosition())

    def mass_move_here(self):
        if not self.selected_indices:
            xbmcgui.Dialog().notification("Error", "No has seleccionado nada", xbmcgui.NOTIFICATION_WARNING)
            return
            
        self.pending_move = True
        self.setFocus(self.panel)
        xbmcgui.Dialog().notification("Mover a...", "Haz Click en la posición de destino", xbmcgui.NOTIFICATION_INFO, 3000)

    def execute_mass_move(self, target_idx):
        # Lógica especial para el primer elemento
        insert_after = True
        if target_idx == 0:
            # Preguntar si quiere ponerlo al principio absoluto o debajo del primero
            ret = xbmcgui.Dialog().select("Mover a...", ["Antes (Al principio)", "Después"])
            if ret < 0: return # Cancelado
            if ret == 0: insert_after = False
            
        # Usamos la lógica de mover
        items_to_move = []
        indices = sorted(list(self.selected_indices))
        
        # Extraer items
        for i in indices:
            items_to_move.append(self.entries[i])
            
        # Borrar originales
        for i in reversed(indices):
            self.entries.pop(i)
            
        # Recalcular destino
        # Calculamos la posición corregida tras los borrados
        deleted_before = sum(1 for x in indices if x < target_idx)
        
        if insert_after:
            # Insertar DESPUÉS (+1)
            insert_pos = max(0, target_idx - deleted_before + 1)
        else:
            # Insertar ANTES (pos tal cual)
            insert_pos = max(0, target_idx - deleted_before)
        
        # Insertar
        for item in reversed(items_to_move):
            self.entries.insert(insert_pos, item)
            
        self.cancel_multiselect()
        self.unsaved_changes = True
        self.refresh_view_keep_selection(insert_pos)
        xbmcgui.Dialog().notification("Movido", "{} elementos".format(len(items_to_move)), xbmcgui.NOTIFICATION_INFO)

    def mass_delete(self):
        if not self.selected_indices: return
        if not xbmcgui.Dialog().yesno("Eliminar", "¿Eliminar {} elementos seleccionados?".format(len(self.selected_indices))):
            return
            
        indices = sorted(list(self.selected_indices), reverse=True)
        for i in indices:
            self.entries.pop(i)
            
        self.cancel_multiselect()
        self.unsaved_changes = True
        self.refresh_view()

    def mass_color(self):
        if not self.selected_indices: return
        
        colors = [
            ('Sin color', None), ('Blanco', 'white'), ('Amarillo', 'yellow'),
            ('Naranja', 'orange'), ('Rojo', 'red'), ('Rosa', 'pink'),
            ('Violeta', 'violet'), ('Azul', 'blue'), ('Cyan', 'cyan'),
            ('Verde', 'green'), ('Lima', 'lime')
        ]
        sel = xbmcgui.Dialog().select('Color para {} items'.format(len(self.selected_indices)), [c[0] for c in colors])
        if sel < 0: return
        color_code = colors[sel][1]
        
        for i in self.selected_indices:
            entry = self.entries[i]
            clean = self._strip_tags(entry.name)
            if color_code:
                entry.name = '[COLOR {}]{}[/COLOR]'.format(color_code, clean)
            else:
                entry.name = clean
                
        self.cancel_multiselect()
        self.unsaved_changes = True
        self.refresh_view()

    def change_icon_selected(self, idx=None):
        if idx is None:
            idx = self.panel.getSelectedPosition()
            
        if idx < 0: 
            xbmcgui.Dialog().notification("Error", "Selecciona un elemento primero", xbmcgui.NOTIFICATION_WARNING, 2000)
            return

        browse_icon = xbmcgui.Dialog().browse(1, 'Seleccionar Nueva Imagen', 'pictures')
        if browse_icon:
            self.entries[idx].thumb = browse_icon
            self.unsaved_changes = True
            self.refresh_view_keep_selection(idx)
            xbmcgui.Dialog().notification("Icono", "Imagen actualizada", xbmcgui.NOTIFICATION_INFO, 1000)

    def handle_add_menu(self):
        opts = ['Añadir Elemento / Addon', 'Añadir Separador']
        sel = xbmcgui.Dialog().select("Añadir...", opts)
        if sel == 0: self.add_custom_item()
        elif sel == 1: self.add_separator()

    def handle_restore_menu(self):
        opts = ['Guardar como Perfil Nuevo', 'Crear copia de seguridad (XML)', 'Restaurar desde backup (XML)', 'Descartar cambios actuales']
        sel = xbmcgui.Dialog().select("Backup / Restaurar", opts)
        
        if sel == 0: self.quick_save_profile() 
        elif sel == 1: self.do_backup_create()
        elif sel == 2: self.do_backup_restore()
        elif sel == 3: 
            self.reload_data()
            self.unsaved_changes = False

    def do_backup_create(self):
        default_name = 'favoritos_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        kb = xbmc.Keyboard(default_name, 'Nombre del backup (sin extensión)')
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText(): return
        
        folder = xbmcgui.Dialog().browse(0, 'Selecciona carpeta para guardar', 'files')
        if not folder: return
        
        path = os.path.join(translatePath(folder), kb.getText() + '.xml')
        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(self.engine.generate_xml(self.entries))
            xbmcgui.Dialog().notification("Backup Creado", kb.getText(), xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception as e:
            xbmcgui.Dialog().ok("Error", str(e))

    def do_backup_restore(self):
        file_path = xbmcgui.Dialog().browse(1, 'Selecciona archivo de backup (.xml)', 'files', '.xml')
        if not file_path: return
        
        full_path = translatePath(file_path)
        if not os.path.exists(full_path):
            xbmcgui.Dialog().ok("Error", "Archivo no encontrado.")
            return
        
        try:
            tree = ET.parse(full_path)
            root = tree.getroot()
            if root.tag != 'favourites':
                xbmcgui.Dialog().ok("Error", "El archivo no parece ser un backup válido.")
                return
            
            # Cargar entradas desde backup
            loaded_entries = []
            for child in root:
                if child.tag == 'favourite':
                    loaded_entries.append(FavouriteEntry.from_xml_element(child))
            
            self.entries = loaded_entries
            self.unsaved_changes = True
            self.refresh_view()
            xbmcgui.Dialog().notification("Restaurado", "Pulsa Confirmar/Volver para guardar.", xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception as e:
            xbmcgui.Dialog().ok("Error", "No se pudo cargar el backup:\n" + str(e))

# --- Punto de Entrada Principal ---

# --- Editor Rápido (sin gráficos) ---

def run_simple_editor():
    engine = FavouritesEngine()
    engine.load()
    entries = engine.entries
    
    while True:
        if not entries:
            xbmcgui.Dialog().ok("Editor Rápido", "No hay favoritos para editar.")
            break
            
        # 1. Mostrar Lista
        names = ["{}. {}".format(i+1, e.name) for i, e in enumerate(entries)]
        idx = xbmcgui.Dialog().select("Selecciona un Favorito para editar", names)
        if idx == -1: break # Cancelar/Atrás pulsado
        
        selected_entry = entries[idx]
        
        # 2. Mostrar Acciones (sin emojis para compatibilidad)
        actions = [
            "Subir 1 posición",
            "Bajar 1 posición",
            "Subir 5 posiciones",
            "Bajar 5 posiciones",
            "Enviar al Inicio",
            "Enviar al Final",
            "Mover a Posición...",
            "Renombrar",
            "Eliminar"
        ]
        
        action = xbmcgui.Dialog().select("Acción para: " + selected_entry.name, actions)
        if action == -1: continue
        
        # 3. Ejecutar Acción
        changed = False
        new_idx = idx
        
        if action == 0: # Subir 1
            new_idx = max(0, idx - 1)
        elif action == 1: # Bajar 1
            new_idx = min(len(entries)-1, idx + 1)
        elif action == 2: # Subir 5
            new_idx = max(0, idx - 5)
        elif action == 3: # Bajar 5
            new_idx = min(len(entries)-1, idx + 5)
        elif action == 4: # Al Inicio
            new_idx = 0
        elif action == 5: # Al Final
            new_idx = len(entries) - 1
        elif action == 6: # Ir a posición
            kb = xbmc.Keyboard("", "Introduce la nueva posición (1-{})".format(len(entries)))
            kb.doModal()
            if kb.isConfirmed() and kb.getText().isdigit():
                pos = int(kb.getText())
                new_idx = max(0, min(len(entries)-1, pos - 1))
            else:
                continue
        
        # Ejecutar Movimiento
        if action <= 6 and new_idx != idx:
            entries.pop(idx)
            entries.insert(new_idx, selected_entry)
            changed = True
            
        elif action == 7: # Renombrar
            kb = xbmc.Keyboard(selected_entry.name, "Renombrar Favorito")
            kb.doModal()
            if kb.isConfirmed() and kb.getText():
                selected_entry.name = kb.getText()
                changed = True
                
        elif action == 8: # Eliminar
            if xbmcgui.Dialog().yesno("Confirmar", "¿Eliminar '{}'?".format(selected_entry.name)):
                entries.pop(idx)
                changed = True
        
        if changed:
            engine.save(engine.generate_xml(entries))
            xbmcgui.Dialog().notification("Editor Rápido", "Guardado", xbmcgui.NOTIFICATION_INFO, 1000)

def run_backup_menu():
    """Menú de backup/restaurar accesible desde el menú principal."""
    options = [
        "Crear Backup (Copia de Seguridad)",
        "Restaurar desde Backup"
    ]
    choice = xbmcgui.Dialog().select("Backup / Restaurar", options)
    
    if choice == 0:  # Crear backup
        engine = FavouritesEngine()
        engine.load()
        if not engine.entries:
            xbmcgui.Dialog().ok("Backup", "No hay favoritos para guardar.")
            return
            
        import datetime
        default_name = 'favoritos_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        kb = xbmc.Keyboard(default_name, 'Nombre del backup (sin extensión)')
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText(): return
        
        folder = xbmcgui.Dialog().browse(0, 'Selecciona carpeta para guardar', 'files')
        if not folder: return
        
        path = os.path.join(translatePath(folder), kb.getText() + '.xml')
        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(engine.generate_xml(engine.entries))
            xbmcgui.Dialog().notification("Backup Creado", kb.getText(), xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception as e:
            xbmcgui.Dialog().ok("Error", str(e))
            
    elif choice == 1:  # Restaurar backup
        file_path = xbmcgui.Dialog().browse(1, 'Selecciona archivo de backup (.xml)', 'files', '.xml')
        if not file_path: return
        
        full_path = translatePath(file_path)
        if not os.path.exists(full_path):
            xbmcgui.Dialog().ok("Error", "Archivo no encontrado.")
            return
        
        try:
            tree = ET.parse(full_path)
            root = tree.getroot()
            if root.tag != 'favourites':
                xbmcgui.Dialog().ok("Error", "El archivo no parece ser un backup válido.")
                return
            
            loaded_entries = []
            for child in root:
                if child.tag == 'favourite':
                    loaded_entries.append(FavouriteEntry.from_xml_element(child))
            
            if not loaded_entries:
                xbmcgui.Dialog().ok("Error", "El backup está vacío.")
                return
                
            if xbmcgui.Dialog().yesno("Confirmar", "¿Reemplazar tus favoritos actuales con el backup?\n({} elementos)".format(len(loaded_entries))):
                engine = FavouritesEngine()
                engine.save(engine.generate_xml(loaded_entries))
                xbmcgui.Dialog().notification("Restaurado", "{} favoritos cargados".format(len(loaded_entries)), xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception as e:
            xbmcgui.Dialog().ok("Error", "No se pudo cargar el backup:\n" + str(e))

def run_templates_editor():
    """Editor para personalizar las plantillas de elementos predefinidos."""
    while True:
        templates = load_templates()
        
        # Construir menú dinámico con todas las categorías
        category_keys = list(templates.keys())
        category_names = []
        for key in category_keys:
            # Formato legible: secciones_kodi -> Secciones Kodi
            display_name = key.replace('_', ' ').title()
            item_count = len(templates[key])
            category_names.append("{} ({} items)".format(display_name, item_count))
        
        # Añadir opciones de gestión
        opts = category_names + [
            '[COLOR lime]+ Añadir Nueva Categoría[/COLOR]',
            '[COLOR orange]Restablecer a valores por defecto[/COLOR]',
            '[COLOR cyan]Exportar Plantillas[/COLOR]',
            '[COLOR cyan]Importar Plantillas[/COLOR]',
            '[COLOR gray]« Volver[/COLOR]'
        ]
        
        sel = xbmcgui.Dialog().select('Editor de Plantillas', opts)
        
        if sel == -1 or sel == len(opts) - 1: return # Volver
        
        # Importar Plantillas
        if sel == len(opts) - 2:
            file_path = xbmcgui.Dialog().browse(1, 'Selecciona archivo de plantillas (.json)', 'files', '.json')
            if file_path:
                full_path = translatePath(file_path)
                try:
                    with open(full_path, 'r', encoding='utf-8') as f:
                        imported = json.load(f)
                    
                    # Validar estructura básica
                    if not isinstance(imported, dict):
                        raise ValueError("Formato inválido")
                    
                    # Preguntar si reemplazar o fusionar
                    merge_opts = ['Reemplazar todo', 'Fusionar (añadir categorías nuevas)', 'Cancelar']
                    merge_sel = xbmcgui.Dialog().select('¿Cómo importar?', merge_opts)
                    
                    if merge_sel == 0: # Reemplazar
                        save_templates(imported)
                        xbmcgui.Dialog().notification("Importado", "Plantillas reemplazadas", xbmcgui.NOTIFICATION_INFO)
                    elif merge_sel == 1: # Fusionar
                        current = load_templates()
                        for key, items in imported.items():
                            if key in current:
                                # Añadir items que no existan
                                existing_names = [i['name'] for i in current[key]]
                                for item in items:
                                    if item['name'] not in existing_names:
                                        current[key].append(item)
                            else:
                                current[key] = items
                        save_templates(current)
                        xbmcgui.Dialog().notification("Fusionado", "Categorías añadidas", xbmcgui.NOTIFICATION_INFO)
                except Exception as e:
                    xbmcgui.Dialog().ok("Error", "No se pudo importar:\n" + str(e))
            continue
        
        # Exportar Plantillas
        if sel == len(opts) - 3:
            folder = xbmcgui.Dialog().browse(0, 'Selecciona carpeta para guardar', 'files')
            if folder:
                default_name = 'plantillas_favoritos_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
                kb = xbmc.Keyboard(default_name, 'Nombre del archivo (sin extensión)')
                kb.doModal()
                if kb.isConfirmed() and kb.getText():
                    file_path = os.path.join(translatePath(folder), kb.getText() + '.json')
                    try:
                        current = load_templates()
                        with open(file_path, 'w', encoding='utf-8') as f:
                            json.dump(current, f, ensure_ascii=False, indent=4)
                        xbmcgui.Dialog().notification("Exportado", kb.getText(), xbmcgui.NOTIFICATION_INFO)
                    except Exception as e:
                        xbmcgui.Dialog().ok("Error", "No se pudo exportar:\n" + str(e))
            continue
        
        # Restablecer
        if sel == len(opts) - 4:
            if xbmcgui.Dialog().yesno("Confirmar", "¿Restablecer todas las plantillas a los valores por defecto?\nEsto eliminará las categorías personalizadas."):
                default_templates = {
                    "secciones_kodi": [
                        {"name": "Películas", "path": "ActivateWindow(Videos,MovieTitles)", "icon": "DefaultMovies.png"},
                        {"name": "Series TV", "path": "ActivateWindow(Videos,TVShowTitles)", "icon": "DefaultTVShows.png"},
                        {"name": "Hogar / Inicio", "path": "ActivateWindow(Home)", "icon": "DefaultHome.png"},
                        {"name": "Televisión (PVR)", "path": "ActivateWindow(TVChannels)", "icon": "DefaultLiveTV.png"},
                        {"name": "Guía TV (EPG)", "path": "ActivateWindow(TVGuide)", "icon": "DefaultEPG.png"},
                        {"name": "Radio", "path": "ActivateWindow(Radio)", "icon": "DefaultRadio.png"},
                        {"name": "Música", "path": "ActivateWindow(Music)", "icon": "DefaultMusic.png"},
                        {"name": "Videoclips", "path": "ActivateWindow(Videos,MusicVideoTitles)", "icon": "DefaultMusicVideos.png"},
                        {"name": "El Tiempo", "path": "ActivateWindow(Weather)", "icon": "DefaultWeather.png"},
                        {"name": "Imágenes", "path": "ActivateWindow(Pictures)", "icon": "DefaultPicture.png"},
                        {"name": "Ajustes", "path": "ActivateWindow(Settings)", "icon": "DefaultIconSettings.png"},
                        {"name": "Gestor de Archivos", "path": "ActivateWindow(FileManager)", "icon": "DefaultFile.png"},
                        {"name": "Info del Sistema", "path": "ActivateWindow(SystemInfo)", "icon": "DefaultIconInfo.png"},
                        {"name": "Eventos / Log", "path": "ActivateWindow(EventLog)", "icon": "DefaultIconInfo.png"},
                        {"name": "Addons (Explorador)", "path": "ActivateWindow(AddonBrowser)", "icon": "DefaultAddon.png"}
                    ],
                    "comandos_sistema": [
                        {"name": "Menú Apagar / Reiniciar", "path": "ActivateWindow(ShutdownMenu)", "icon": "DefaultIconPower.png"},
                        {"name": "Actualizar Librería (Video)", "path": "UpdateLibrary(video)", "icon": "DefaultIconSync.png"},
                        {"name": "Limpiar Librería (Video)", "path": "CleanLibrary(video)", "icon": "DefaultAddon.png"},
                        {"name": "Recargar Skin", "path": "ReloadSkin()", "icon": "DefaultIconRepeat.png"},
                        {"name": "Ajustes de Skin", "path": "ActivateWindow(SkinSettings)", "icon": "DefaultAddon.png"},
                        {"name": "Gestor de Archivos", "path": "ActivateWindow(FileManager)", "icon": "DefaultFile.png"}
                    ]
                }
                save_templates(default_templates)
                xbmcgui.Dialog().notification("Plantillas", "Restablecidas", xbmcgui.NOTIFICATION_INFO)
            continue
        
        if sel == len(opts) - 5: # Añadir nueva categoría
            kb = xbmc.Keyboard('', 'Nombre de la nueva categoría')
            kb.doModal()
            if kb.isConfirmed() and kb.getText():
                new_cat_name = kb.getText().strip()
                # Convertir a clave válida: "Mis Addons" -> "mis_addons"
                new_cat_key = new_cat_name.lower().replace(' ', '_')
                
                if new_cat_key in templates:
                    xbmcgui.Dialog().notification("Error", "Ya existe una categoría con ese nombre", xbmcgui.NOTIFICATION_WARNING)
                else:
                    templates[new_cat_key] = []
                    save_templates(templates)
                    xbmcgui.Dialog().notification("Creada", new_cat_name, xbmcgui.NOTIFICATION_INFO)
            continue
        
        # Editar categoría seleccionada
        category = category_keys[sel]
        category_display = category.replace('_', ' ').title()
        
        while True:
            templates = load_templates()
            items = templates.get(category, [])
            
            # Construir lista
            names = [i['name'] for i in items]
            names.append('[COLOR lime]+ Añadir Nuevo[/COLOR]')
            names.append('[COLOR red]Eliminar esta Categoría[/COLOR]')
            names.append('[COLOR gray]« Volver[/COLOR]')
            
            item_sel = xbmcgui.Dialog().select(category_display, names)
            
            if item_sel == -1 or item_sel == len(names) - 1: break # Volver
            
            if item_sel == len(names) - 2: # Eliminar categoría
                if xbmcgui.Dialog().yesno("Confirmar", "¿Eliminar la categoría '{}' y todos sus elementos?".format(category_display)):
                    del templates[category]
                    save_templates(templates)
                    xbmcgui.Dialog().notification("Eliminada", category_display, xbmcgui.NOTIFICATION_INFO)
                    break
                continue
            
            if item_sel == len(names) - 3: # Añadir nuevo
                # Nombre
                kb = xbmc.Keyboard('', 'Nombre del elemento')
                kb.doModal()
                if not kb.isConfirmed() or not kb.getText(): continue
                new_name = kb.getText()
                
                # Comando/Ruta
                kb = xbmc.Keyboard('', 'Comando o Ruta (Ej: ActivateWindow(...))')
                kb.doModal()
                if not kb.isConfirmed() or not kb.getText(): continue
                new_path = kb.getText()
                
                # Icono - Elegir método
                icon_opts = ['Escribir nombre (Ej: DefaultMovies.png)', 'Buscar imagen en explorador']
                icon_sel = xbmcgui.Dialog().select('Seleccionar Icono', icon_opts)
                
                if icon_sel == 0: # Escribir
                    kb = xbmc.Keyboard('DefaultAddon.png', 'Nombre del icono')
                    kb.doModal()
                    new_icon = kb.getText() if kb.isConfirmed() and kb.getText() else 'DefaultAddon.png'
                elif icon_sel == 1: # Explorar
                    browse_result = xbmcgui.Dialog().browse(1, 'Seleccionar Imagen', 'pictures')
                    new_icon = browse_result if browse_result else 'DefaultAddon.png'
                else:
                    new_icon = 'DefaultAddon.png'
                
                # Guardar
                items.append({"name": new_name, "path": new_path, "icon": new_icon})
                templates[category] = items
                save_templates(templates)
                xbmcgui.Dialog().notification("Añadido", new_name, xbmcgui.NOTIFICATION_INFO)
                
            else: # Editar existente
                selected_item = items[item_sel]
                
                actions = ['Editar Nombre', 'Editar Comando', 'Editar Icono', 'Eliminar', 'Cancelar']
                action = xbmcgui.Dialog().select(selected_item['name'], actions)
                
                if action == 0: # Nombre
                    kb = xbmc.Keyboard(selected_item['name'], 'Nuevo Nombre')
                    kb.doModal()
                    if kb.isConfirmed() and kb.getText():
                        items[item_sel]['name'] = kb.getText()
                        templates[category] = items
                        save_templates(templates)
                        
                elif action == 1: # Comando
                    kb = xbmc.Keyboard(selected_item['path'], 'Nuevo Comando')
                    kb.doModal()
                    if kb.isConfirmed() and kb.getText():
                        items[item_sel]['path'] = kb.getText()
                        templates[category] = items
                        save_templates(templates)
                        
                elif action == 2: # Icono
                    icon_opts = ['Escribir nombre (Ej: DefaultMovies.png)', 'Buscar imagen en explorador']
                    icon_sel = xbmcgui.Dialog().select('Seleccionar Icono', icon_opts)
                    
                    new_icon = None
                    if icon_sel == 0: # Escribir
                        kb = xbmc.Keyboard(selected_item['icon'], 'Nuevo Icono')
                        kb.doModal()
                        if kb.isConfirmed() and kb.getText():
                            new_icon = kb.getText()
                    elif icon_sel == 1: # Explorar
                        browse_result = xbmcgui.Dialog().browse(1, 'Seleccionar Imagen', 'pictures')
                        if browse_result:
                            new_icon = browse_result
                    
                    if new_icon:
                        items[item_sel]['icon'] = new_icon
                        templates[category] = items
                        save_templates(templates)
                        
                elif action == 3: # Eliminar
                    if xbmcgui.Dialog().yesno("Confirmar", "¿Eliminar '{}'?".format(selected_item['name'])):
                        items.pop(item_sel)
                        templates[category] = items
                        save_templates(templates)
                        xbmcgui.Dialog().notification("Eliminado", selected_item['name'], xbmcgui.NOTIFICATION_INFO)

def show_about_dialog():
    msg = ("[B]Flow FavManager[/B]\n"
           "[COLOR gray]-----------------------------------------------[/COLOR]\n"
           "Para más información y proyectos visitar:\n"
           "https://github.com/fullstackcurso/")
    xbmcgui.Dialog().ok("Acerca de", msg)

def run_profiles_menu():
    """Menú para gestionar perfiles de favoritos."""
    while True:
        profiles = get_profiles()
        
        # Opciones
        display_list = ["[B]+ Crear Perfil[/B] (Guardar estado actual)", 
                        "[B]+ Importar desde XML[/B]",
                        "[B]+ Exportar actuales a XML[/B]"]
                        
        for p in profiles:
            display_list.append(f"{p['name']} | [I]{p['date']}[/I] | {len(p['entries'])} items")
            
        sel = xbmcgui.Dialog().select("Gestor de Perfiles", display_list)
        if sel == -1: break
        
        if sel == 0: # Crear Nuevo
            kb = xbmc.Keyboard('', 'Nombre del nuevo perfil')
            kb.doModal()
            if kb.isConfirmed() and kb.getText():
                name = kb.getText()
                # Cargar favoritos actuales del sistema
                eng = FavouritesEngine()
                eng.load()
                if save_profile(name, eng.entries):
                    xbmcgui.Dialog().notification("Perfil Creado", f"Guardado '{name}'", xbmcgui.NOTIFICATION_INFO)
                    log_audit("PROFILE_CREATED", f"Perfil '{name}' creado con {len(eng.entries)} items")
                    # Refrescar contenedor si venimos desde Explorar
                    xbmc.executebuiltin('Container.Refresh')
                    break # Salir del menú tras crear
            continue
            
        elif sel == 1: # Importar XML
            path = xbmcgui.Dialog().browse(1, 'Seleccionar archivo favourites.xml', 'files', '.xml')
            if path:
                try:
                    log_debug(f"Importando XML desde: {path}")
                    tree = ET.parse(path)
                    root = tree.getroot()
                    entries = []
                    
                    for child in root:
                        if child.tag == 'favourite':
                            try:
                                entry = FavouriteEntry.from_xml_element(child)
                                entries.append(entry)
                            except Exception as inner:
                                log_debug(f"Error parseando elemento: {inner}")
                    
                    log_debug(f"Encontrados {len(entries)} favoritos")
                    
                    if not entries:
                        xbmcgui.Dialog().notification("Error", "No se encontraron favoritos válidos", xbmcgui.NOTIFICATION_ERROR)
                        continue

                    kb = xbmc.Keyboard('Perfil Importado', 'Nombre para el perfil')
                    kb.doModal()
                    if kb.isConfirmed():
                        p_name = kb.getText() or 'Perfil Importado'
                        save_profile(p_name, entries)
                        xbmcgui.Dialog().notification("Importado", f"{len(entries)} favoritos añadidos", xbmcgui.NOTIFICATION_INFO)
                        log_audit("PROFILE_IMPORTED", f"Perfil '{p_name}' importado desde XML ({len(entries)} items)")
                        xbmc.executebuiltin('Container.Refresh')
                        break # Salir y refrescar
                except Exception as e:
                    import traceback
                    tb = traceback.format_exc()
                    log_debug("ERROR IMPORT: " + tb)
                    xbmcgui.Dialog().textviewer("Error Importación", str(e) + "\n\n" + tb)
            continue
            
        elif sel == 2: # Exportar Actuales
            dest = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
            if dest:
                try:
                    eng = FavouritesEngine()
                    eng.load() # Cargar actuales
                    
                    file_name = f"favourites_export_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.xml"
                    path = os.path.join(dest, file_name)
                    
                    root = ET.Element('favourites')
                    for e in eng.entries:
                        item = ET.SubElement(root, 'favourite')
                        item.set('name', e.name)
                        item.set('thumb', e.thumb)
                        item.text = e.url
                    
                    tree = ET.ElementTree(root)
                    tree.write(path, encoding='utf-8', xml_declaration=True)
                    xbmcgui.Dialog().notification("Exportado", file_name, xbmcgui.NOTIFICATION_INFO)
                except Exception as e:
                    xbmcgui.Dialog().ok("Error Exportando", str(e))
            continue
        
        # Acciones sobre perfil existente
        prof = profiles[sel - 3]
        opts = ['[B]Cargar Perfil[/B] (Reemplaza favoritos actuales)', 'Renombrar', 'Exportar a XML', 'Eliminar', 'Cancelar']
        act = xbmcgui.Dialog().select(f"Perfil: {prof['name']}", opts)
        
        if act == 0: # Cargar
            if xbmcgui.Dialog().yesno("Cargar Perfil", f"¿SEGURO? Esto reemplazará tus favoritos actuales por los de '{prof['name']}'.\nSe recomienda hacer un backup antes."):
                eng = FavouritesEngine()
                eng.entries = load_profile(prof['filename'])
                eng.save()
                xbmcgui.Dialog().notification("Perfil Cargado", "Favoritos actualizados", xbmcgui.NOTIFICATION_INFO)
                log_audit("PROFILE_LOADED", f"Perfil '{prof['name']}' cargado como favoritos activos")
                break
                
        elif act == 1: # Renombrar
            kb = xbmc.Keyboard(prof['name'], 'Renombrar perfil')
            kb.doModal()
            if kb.isConfirmed() and kb.getText():
                new_name = kb.getText()
                if new_name != prof['name']:
                    # Cargar, guardar con nuevo nombre, borrar viejo
                    entries = load_profile(prof['filename'])
                    save_profile(new_name, entries)
                    delete_profile(prof['filename'])
                    xbmcgui.Dialog().notification("Renombrado", f"Ahora es '{new_name}'", xbmcgui.NOTIFICATION_INFO)
                    log_audit("PROFILE_RENAMED", f"Perfil renombrado de '{prof['name']}' a '{new_name}'")

        elif act == 2: # Exportar
            # Seleccionar carpeta destino
            dest = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
            if dest:
                try:
                    safe_name = "".join([c for c in prof['name'] if c.isalnum() or c in (' ', '-', '_')]).strip()
                    file_name = f"{safe_name}.xml"
                    path = os.path.join(dest, file_name)
                    
                    entries = load_profile(prof['filename'])
                    
                    root = ET.Element('favourites')
                    for e in entries:
                        item = ET.SubElement(root, 'favourite')
                        item.set('name', e.name)
                        item.set('thumb', e.thumb)
                        item.text = e.url
                    
                    # Guardar
                    tree = ET.ElementTree(root)
                    tree.write(path, encoding='utf-8', xml_declaration=True)
                    
                    xbmcgui.Dialog().notification("Exportado", f"Guardado en {file_name}", xbmcgui.NOTIFICATION_INFO)
                except Exception as e:
                    xbmcgui.Dialog().ok("Error Exportando", str(e))

        elif act == 3: # Eliminar
            if xbmcgui.Dialog().yesno("Eliminar Perfil", f"¿Borrar permanentemente el perfil '{prof['name']}'?"):
                delete_profile(prof['filename'])
                log_audit("PROFILE_DELETED", f"Perfil '{prof['name']}' eliminado")

def router(param):
    try:
        if '/profiles' in param:
            run_profiles_menu()
            
        elif '/dialog' in param:
            # Always use the new single editor.xml
            xml = 'editor.xml'
            
            # Decide layout property based on settings
            # view_mode: 0 = Lista (default), 1 = Cuadrícula
            view_setting = ADDON.getSetting('view_mode') or '0'
            thumb_size = ADDON.getSetting('icon_scale') or '0'
            font_size = ADDON.getSetting('text_scale') or '1'
            
            if view_setting == '1':  # Cuadrícula
                if thumb_size == '0':
                    prop_mode = '1' # Grid Small
                else:
                    prop_mode = '0' # Grid Large
            else: # Lista
                # Si Font > Pequeño (0) O Thumb > Pequeño (0), usar Lista Grande
                # font_size: 0=Pequeño, 1=Mediano, 2=Grande
                if thumb_size == '1' or font_size != '0':
                    prop_mode = '3' # List Large
                else:
                    prop_mode = '2' # List Compact
            
            gui = FavouritesEditor(xml, PATHS['addon_path'], 'Default', '1080i')
            gui.setProperty('view_mode', prop_mode)
            gui.setProperty('addonIcon', os.path.join(PATHS['addon_path'], 'icon.png'))
            gui.doModal()
            del gui
            
        elif '/simple_editor' in param:
            run_simple_editor()
            
        elif '/backup_menu' in param:
            run_backup_menu()
            
        elif '/save_reload' in param:
            # Ask to clear cache
            if xbmcgui.Dialog().yesno("Mantenimiento", "¿Quieres borrar el caché de imágenes (Texturas) antes de recargar?\nEsto arregla problemas con iconos antiguos."):
                # Clear Texture Cache logic
                try:
                    db_path = translatePath('special://profile/Database/Textures13.db')
                    thumbs_path = translatePath('special://profile/Thumbnails/')
                    
                    # 1. Try to delete Database (Might fail on Windows, we ignore it)
                    try:
                        if os.path.exists(db_path):
                            os.remove(db_path)
                    except Exception:
                        pass # File locked, continue to delete images
                    
                    # 2. Delete Thumbnails folder contents (This forces reload)
                    if os.path.exists(thumbs_path):
                        try:
                            shutil.rmtree(thumbs_path)
                            xbmc.sleep(200)
                            os.mkdir(thumbs_path)
                        except Exception:
                            pass # Some files might be locked, ignore
                        
                    xbmcgui.Dialog().notification("Mantenimiento", "Actualizando texturas...", xbmcgui.NOTIFICATION_INFO, 2000)
                    xbmc.sleep(1000)
                except Exception as e:
                    log_debug("Cache warning: " + str(e))

            # Always reload profile to apply changes/restart skin
            xbmc.executebuiltin('LoadProfile(%s)' % xbmc.getInfoLabel('System.ProfileName'))
            
        elif '/settings' in param:
            # Submenú de Configuración
            while True:
                audit_enabled = ADDON.getSetting('enable_audit_log') == 'true'
                audit_label = "Log de Auditoría: [COLOR lime]ON[/COLOR]" if audit_enabled else "Log de Auditoría: [COLOR gray]OFF[/COLOR]"
                
                opts = [
                    'Opciones del Editor Visual',
                    'Editor de Plantillas',
                    'Seguridad y Contraseña',
                    audit_label,
                    'Volver'
                ]
                sel = xbmcgui.Dialog().select('Configuración', opts)
                
                if sel == 0:
                    ADDON.openSettings()
                elif sel == 1:
                    run_templates_editor()
                elif sel == 2:
                    run_security_menu()
                elif sel == 3:
                    # Submenú Log de Auditoría
                    while True:
                        audit_on = ADDON.getSetting('enable_audit_log') == 'true'
                        toggle_text = "Desactivar Registro" if audit_on else "Activar Registro"
                        
                        log_opts = [
                            f"Estado: [COLOR {'lime' if audit_on else 'gray'}]{'ACTIVADO' if audit_on else 'DESACTIVADO'}[/COLOR]",
                            toggle_text,
                            "Ver Log de Auditoría",
                            "Borrar Log",
                            "[COLOR gray]« Volver[/COLOR]"
                        ]
                        log_sel = xbmcgui.Dialog().select("Log de Auditoría", log_opts)
                        
                        if log_sel == 1:  # Toggle
                            new_val = 'false' if audit_on else 'true'
                            ADDON.setSetting('enable_audit_log', new_val)
                            xbmcgui.Dialog().notification("Log", "Activado" if new_val == 'true' else "Desactivado", xbmcgui.NOTIFICATION_INFO)
                        elif log_sel == 2:  # Ver Log
                            if os.path.exists(AUDIT_FILE):
                                try:
                                    with open(AUDIT_FILE, 'r', encoding='utf-8') as f:
                                        content = f.read()
                                    if content.strip():
                                        xbmcgui.Dialog().textviewer("Log de Auditoría", content)
                                    else:
                                        xbmcgui.Dialog().ok("Log Vacío", "No hay eventos registrados todavía.")
                                except Exception as e:
                                    xbmcgui.Dialog().ok("Error", f"No se pudo leer el log:\n{e}")
                            else:
                                xbmcgui.Dialog().ok("Log No Existe", "Activa el registro y realiza alguna acción para generar eventos.")
                        elif log_sel == 3:  # Borrar
                            if os.path.exists(AUDIT_FILE):
                                if xbmcgui.Dialog().yesno("Borrar Log", "¿Eliminar todo el historial de auditoría?"):
                                    try:
                                        os.remove(AUDIT_FILE)
                                        xbmcgui.Dialog().notification("Log", "Historial borrado", xbmcgui.NOTIFICATION_INFO)
                                    except:
                                        pass
                            else:
                                xbmcgui.Dialog().notification("Info", "No hay log que borrar", xbmcgui.NOTIFICATION_INFO)
                        else:
                            break
                else:
                    break  # Volver
            
        elif '/templates_editor' in param:
            run_templates_editor()
            
        elif '/about' in param:
            show_about_dialog()
            
        elif '/open_favourites' in param:
            # Detectar versión para compatibilidad (Kodi 21+ usa FavouritesBrowser)
            version = xbmc.getInfoLabel('System.BuildVersion')
            major = 19
            try:
                if version: major = int(version.split('.')[0])
            except: pass
            
            if major >= 21:
                xbmc.executebuiltin('ActivateWindow(FavouritesBrowser)')
            else:
                xbmc.executebuiltin('ActivateWindow(Favourites)')
            
        elif '/execute' in param:
            # Puente para ejecutar comandos de Kodi (ActivateWindow, RunAddon, etc)
            import urllib.parse
            parsed = urllib.parse.urlparse(param)
            args = urllib.parse.parse_qs(parsed.query)
            cmd = args.get('cmd', [''])[0]
            
            if cmd:
                log_debug("Ejecutando comando: " + cmd)
                xbmc.executebuiltin(cmd)
            return

        elif '/explore_profile' in param:
            # Listar contenido de un perfil específico
            import urllib.parse
            
            parsed = urllib.parse.urlparse(param)
            args = urllib.parse.parse_qs(parsed.query)
            filename = args.get('file', [''])[0]
            
            if not filename and len(sys.argv) > 2:
                args = urllib.parse.parse_qs(sys.argv[2].lstrip('?'))
                filename = args.get('file', [''])[0]

            if not filename:
                log_debug("Explore Profile: No filename found in URL: " + str(param))
                xbmcplugin.endOfDirectory(PLUGIN_ID, False)
                return

            try:
                entries = load_profile(filename)
                
                if not entries:
                    li = xbmcgui.ListItem(label="[Carpeta Vacía]")
                    xbmcplugin.addDirectoryItem(PLUGIN_ID, "", li, False)
                
                for entry in entries:
                    li, target_url, is_folder = build_list_item(entry)
                    xbmcplugin.addDirectoryItem(PLUGIN_ID, target_url, li, is_folder)
                
                xbmcplugin.endOfDirectory(PLUGIN_ID)
                
            except Exception as e:
                log_debug("Error explorando perfil: " + str(e))
                xbmcgui.Dialog().notification("Error", "No se pudo leer el perfil", xbmcgui.NOTIFICATION_ERROR)
                xbmcplugin.endOfDirectory(PLUGIN_ID, False)

        elif '/search_profiles' in param:
            # Buscar en todos los perfiles
            import urllib.parse
            parsed = urllib.parse.urlparse(param)
            args = urllib.parse.parse_qs(parsed.query)
            query = args.get('q', [''])[0]
            
            if not query:
                # Pedir término de búsqueda
                kb = xbmc.Keyboard('', 'Buscar en todos los perfiles')
                kb.doModal()
                if not kb.isConfirmed() or not kb.getText():
                    xbmcplugin.endOfDirectory(PLUGIN_ID, False)
                    return
                query = kb.getText()
            
            # Buscar en todos los perfiles
            profiles = get_profiles()
            results = []
            query_lower = query.lower()
            
            for p in profiles:
                for entry_data in p.get('entries', []):
                    entry_name = entry_data.get('name', '')
                    # Limpiar tags de color para buscar
                    clean_name = re.sub(r'\[COLOR[^\]]*\]|\[/COLOR\]|\[B\]|\[/B\]|\[I\]|\[/I\]', '', entry_name)
                    if query_lower in clean_name.lower():
                        results.append({
                            'name': entry_name,
                            'thumb': entry_data.get('thumb', ''),
                            'url': entry_data.get('url', ''),
                            'profile': p['name']
                        })
            
            xbmcplugin.setContent(PLUGIN_ID, 'files')
            
            if not results:
                li = xbmcgui.ListItem(label=f"[COLOR gray]Sin resultados para '{query}'[/COLOR]")
                li.setInfo('video', {'plot': 'No se encontraron elementos que coincidan con tu búsqueda.'})
                xbmcplugin.addDirectoryItem(PLUGIN_ID, '', li, False)
            else:
                # Mostrar resultados
                for r in results:
                    # Crear objeto temporal para usar build_list_item
                    temp_entry = FavouriteEntry(r['name'], r['thumb'], r['url'])
                    
                    li, target_url, is_folder = build_list_item(temp_entry)
                    
                    # Personalizar etiqueta para búsqueda (añadir nombre de perfil)
                    display_name = f"{r['name']} [COLOR gray]({r['profile']})[/COLOR]"
                    li.setLabel(display_name)
                    li.setInfo('video', {'plot': f"Desde perfil: {r['profile']}\nURL: {r['url'][:80]}..."})
                    
                    xbmcplugin.addDirectoryItem(PLUGIN_ID, target_url, li, is_folder)
            
            xbmcplugin.endOfDirectory(PLUGIN_ID)

        elif '/delete_profile' in param:
            # Acción para borrar perfil desde menú contextual
            import urllib.parse
            parsed = urllib.parse.urlparse(param)
            args = urllib.parse.parse_qs(parsed.query)
            filename = args.get('file', [''])[0]
            
            if filename and xbmcgui.Dialog().yesno("Eliminar Perfil", "¿Seguro que quieres eliminar este perfil para siempre?"):
                if delete_profile(filename):
                    xbmcgui.Dialog().notification("Eliminado", "Perfil borrado correctamente", xbmcgui.NOTIFICATION_INFO)
                    xbmc.executebuiltin('Container.Refresh') # Recargar lista visualmente
                else:
                    xbmcgui.Dialog().notification("Error", "No se pudo borrar el archivo", xbmcgui.NOTIFICATION_ERROR)
            return

        elif '/rename_profile' in param:
            # Acción para renombrar perfil desde menú contextual
            import urllib.parse
            parsed = urllib.parse.urlparse(param)
            args = urllib.parse.parse_qs(parsed.query)
            filename = args.get('file', [''])[0]
            current_name = args.get('name', [''])[0]
            
            if filename:
                kb = xbmc.Keyboard(current_name, 'Nuevo nombre del perfil')
                kb.doModal()
                if kb.isConfirmed() and kb.getText():
                    new_name = kb.getText()
                    try:
                        # Cargar, guardar con nuevo nombre y borrar viejo
                        entries = load_profile(filename)
                        if save_profile(new_name, entries):
                            delete_profile(filename)
                            xbmcgui.Dialog().notification("Renombrado", "Perfil actualizado", xbmcgui.NOTIFICATION_INFO)
                            xbmc.executebuiltin('Container.Refresh')
                    except Exception as e:
                         xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)
            return

        elif '/widget' in param:
            # Ruta optimizada para Widgets
            import urllib.parse
            parsed = urllib.parse.urlparse(param)
            args = urllib.parse.parse_qs(parsed.query)
            
            # Obtener nombre de perfil (o archivo)
            profile_val = args.get('profile', [''])[0] or args.get('file', [''])[0]
            
            entries = []
            if not profile_val:
                # Si no se especifica, intentar cargar el último usado o el default
                # (Por ahora, listamos carpetas de perfiles si no hay params)
                profiles = get_profiles()
                for p in profiles:
                    url = BASE_URL + 'widget?profile=' + urllib.parse.quote(p['filename'])
                    li = xbmcgui.ListItem(label=p['name'])
                    li.setArt({'thumb': 'DefaultFolder.png', 'icon': 'DefaultFolder.png'})
                    xbmcplugin.addDirectoryItem(PLUGIN_ID, url, li, True)
                xbmcplugin.endOfDirectory(PLUGIN_ID)
                return
            else:
                # Cargar perfil específico
                # Soporta nombre de archivo "profile_xyz.json" o nombre "Mis Favoritos"
                
                # Intentar cargar directo (asumiendo filename)
                entries = load_profile(profile_val)
                
                # Si falla o vacío, buscar por nombre
                if not entries and not profile_val.endswith('.json'):
                    profiles = get_profiles()
                    for p in profiles:
                        if p['name'] == profile_val:
                            entries = load_profile(p['filename'])
                            break
            
            xbmcplugin.setContent(PLUGIN_ID, 'files')
            
            if not entries:
                # Mostrar item vacío
                li = xbmcgui.ListItem(label="(Vacío)")
                xbmcplugin.addDirectoryItem(PLUGIN_ID, "", li, False)
            else:
                for entry in entries:
                    li, target_url, is_folder = build_list_item(entry)
                    xbmcplugin.addDirectoryItem(PLUGIN_ID, target_url, li, is_folder)
            
            xbmcplugin.endOfDirectory(PLUGIN_ID)

        elif '/explore' in param:
            # Listar carpetas de perfiles
            profiles = get_profiles()
            
            xbmcplugin.setContent(PLUGIN_ID, 'files')
            
            # --- GESTOR DE PERFILES (Botón Superior) ---
            li = xbmcgui.ListItem(label="[COLOR violet][B]GESTOR DE PERFILES (Crear / Importar / Guardar)[/B][/COLOR]")
            li.setArt({'icon': 'DefaultAddonService.png', 'thumb': 'DefaultAddonService.png'})
            li.setInfo('video', {'plot': 'Herramientas para crear nuevos perfiles, importar desde XML o guardar el estado actual.'})
            url_manager = BASE_URL + 'profiles'
            xbmcplugin.addDirectoryItem(PLUGIN_ID, url_manager, li, False)
            # ------------------------------------------
            
            # --- BUSCAR EN TODOS LOS PERFILES ---
            li = xbmcgui.ListItem(label="[COLOR cyan][B]Buscar en todos los perfiles[/B][/COLOR]")
            li.setArt({'icon': 'DefaultAddonsSearch.png', 'thumb': 'DefaultAddonsSearch.png'})
            li.setInfo('video', {'plot': 'Busca elementos por nombre en todos tus perfiles guardados.'})
            url_search = BASE_URL + 'search_profiles'
            xbmcplugin.addDirectoryItem(PLUGIN_ID, url_search, li, True)
            # ------------------------------------
            
            # --- VISTA WIDGETS LIMPIA ---
            li = xbmcgui.ListItem(label="[COLOR yellow][B]Vista Widgets (Navegación Limpia)[/B][/COLOR]")
            li.setArt({'icon': 'DefaultPlaylist.png', 'thumb': 'DefaultPlaylist.png'})
            li.setInfo('video', {'plot': 'Muestra tus perfiles sin botones de gestión. Ideal para añadir a la pantalla de inicio de tu skin como Widget.'})
            url_widget = BASE_URL + 'widget'
            xbmcplugin.addDirectoryItem(PLUGIN_ID, url_widget, li, True)
            # ----------------------------
            
            for p in profiles:
                # Crear URL para entrar en el perfil
                import urllib.parse
                url = BASE_URL + 'explore_profile?file=' + urllib.parse.quote(p['filename'])
                
                li = xbmcgui.ListItem(label=p['name'])
                li.setArt({'icon': 'DefaultUser.png'})
                li.setInfo('video', {'plot': f"{len(p['entries'])} elementos.\nModificado: {p['date']}"})
                
                # --- MENÚ CONTEXTUAL ---
                # Definir comandos para el click derecho
                cmd_delete = f"RunPlugin({BASE_URL}delete_profile?file={urllib.parse.quote(p['filename'])})"
                cmd_rename = f"RunPlugin({BASE_URL}rename_profile?file={urllib.parse.quote(p['filename'])}&name={urllib.parse.quote(p['name'])})"
                
                li.addContextMenuItems([
                    ('Renombrar Perfil', cmd_rename),
                    ('Eliminar Perfil', cmd_delete)
                ])
                
                xbmcplugin.addDirectoryItem(PLUGIN_ID, url, li, True)
                
            xbmcplugin.endOfDirectory(PLUGIN_ID)

        elif '/toggle_ee' in param:
            # Easter Egg Toggle
            current = ADDON.getSetting('easter_egg') == 'true'
            ADDON.setSetting('easter_egg', 'false' if current else 'true')
            xbmc.executebuiltin('Container.Refresh')
            return

        elif '/exit_only' in param:
             xbmc.executebuiltin('Action(Back)')
             
        else:
            # Main Menu construction
            xbmcplugin.setContent(PLUGIN_ID, 'files')
            
            def add_item(label, route, icon_name, desc, color='white', is_folder=False, context_items=None):
                # Construir URL limpia
                full_url = BASE_URL + route.lstrip('/')
                
                # Texto limpio para el título (InfoTag)
                clean_label = label
                
                li = xbmcgui.ListItem(label='[COLOR {}][B]{}[/B][/COLOR]'.format(color, label))
                li.setArt({
                    'thumb': icon_name, 
                    'icon': icon_name
                })
                # Usamos 'video' y 'plot' para que salga la descripción en la mayoría de skins
                li.setInfo('video', {
                    'title': clean_label,
                    'plot': desc, 
                    'plotoutline': desc
                })
                
                if context_items:
                    li.addContextMenuItems(context_items)
                    
                xbmcplugin.addDirectoryItem(PLUGIN_ID, full_url, li, is_folder)

            add_item('Explorar Mis Perfiles', 'explore',
                     'DefaultUser.png',
                     'Navega por tus perfiles como si fueran carpetas. Útil para crear menús y Widgets en Skins.', 'white', is_folder=True)

            add_item('Editor Visual Avanzado', 'dialog', 
                     'DefaultPlaylist.png', 
                     'Editor gráfico con visualización de iconos y colores.', 'cyan')
            
            add_item('Editor Rápido', 'simple_editor', 
                     'DefaultFile.png', 
                     'Editor simple y ligero. Rápido y compatible con todos los dispositivos.', 'violet')

            add_item('Backup / Restaurar', 'backup_menu', 
                     'DefaultHardDisk.png', 
                     'Crear una copia de seguridad de tus favoritos o restaurar una anterior.', 'orange')

            add_item('Recargar Perfil (Ver cambios)', 'save_reload', 
                     'DefaultAddonsUpdates.png', 
                     'Recarga el perfil de Kodi para aplicar los cambios en la interfaz principal.', 'lime')

            add_item('Configuración', 'settings', 
                     'DefaultProgram.png', 
                     'Ajustes del editor visual y editor de plantillas.', 'silver')
            
            add_item('Ver Menú de Favoritos', 'open_favourites', 
                     'DefaultFavourites.png', 
                     'Abre el menú de favoritos de Kodi para ver el resultado.', 'gold')

            # --- EASTER EGG LOGIC ---
            is_ee = ADDON.getSetting('easter_egg') == 'true'
            lbl_about = "Addon hecho por RubénSDFA1labernt" if is_ee else "Acerca de Flow FavManager"
            desc_about = "Información del autor." if is_ee else "Información."
            color_about = "blue" if is_ee else "cornflowerblue"
            
            # Context Menu para activarlo
            ctx_ee = [('Créditos Ocultos', f'RunPlugin({BASE_URL}toggle_ee)')]
            
            add_item(lbl_about, 'about', 
                     'DefaultIconInfo.png', 
                     desc_about, color_about, context_items=ctx_ee)
            # ------------------------

            add_item('Volver / Salir', 'exit_only', 
                     'DefaultFolderBack.png', 
                     'Volver a Kodi.', 'red')
            
            xbmcplugin.endOfDirectory(PLUGIN_ID)

    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        log_debug("CRASH: " + tb)
        xbmcgui.Dialog().textviewer("Error Crítico", str(e) + "\n\n" + tb)

if __name__ == '__main__':
    # Chequeo de seguridad antes de arrancar
    if not check_security_gate():
        # Bloquear acceso - No mostrar nada
        if PLUGIN_ID >= 0:
            xbmcplugin.endOfDirectory(PLUGIN_ID, succeeded=False)
    else:
        # Pasar sys.argv[0] (ruta) y sys.argv[2] (parámetros) para que el router tenga todo
        full_url = sys.argv[0]
        if len(sys.argv) > 2:
            full_url += sys.argv[2]
        router(full_url)
